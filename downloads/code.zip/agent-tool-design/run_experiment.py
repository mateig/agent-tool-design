"""Fresh, phased reproduction of the frozen experiment; invoking main makes paid API calls.

The original experiment.py remains unchanged for provenance. This wrapper reuses its
search, selection, rollout, prompt and API implementations; it changes scheduling only.
"""
import os
os.environ.setdefault("MUJOCO_GL", "egl")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
import argparse
import concurrent.futures as cf
import hashlib
import json
import multiprocessing as mp
from pathlib import Path
import random
import re
import subprocess
import sys
import time
import traceback
from types import SimpleNamespace
import experiment as ex

ROOT = Path(__file__).resolve().parent


def now():
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def check_frozen():
    protocol = json.loads((ROOT / "protocol/frozen_protocol.json").read_text())
    expected = protocol["source_sha256"]
    mismatches = [name for name, digest in expected.items()
                  if not (ROOT / name).is_file()
                  or hashlib.sha256((ROOT / name).read_bytes()).hexdigest() != digest]
    if mismatches:
        raise RuntimeError("Frozen source mismatch: " + ", ".join(mismatches))
    return expected


class WaitingFuture:
    """Ignore a caller's queue-wait timeout; propagate actual worker exceptions."""
    def __init__(self, future):
        self.future = future

    def result(self, timeout=None):
        return self.future.result()


class WaitingPool:
    """Adapter for the frozen search/heldout interfaces; no simulation changes."""
    def __init__(self, pool):
        self.pool = pool

    def submit(self, *args, **kwargs):
        return WaitingFuture(self.pool.submit(*args, **kwargs))


def infrastructure_errors(base):
    errors = []
    for path in sorted((base / "search").glob("*/*/run_*/candidate_[0-9].json")):
        record = json.loads(path.read_text())
        message = record.get("parse_error", "")
        if ("TimeoutError" in message or "BrokenProcessPool" in message
                or "render_error" in record):
            errors.append({"path": str(path.relative_to(base)),
                           "error": message or record.get("render_error")})
    return errors


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", required=True,
                        help="New results directory name; existing tags are rejected.")
    parser.add_argument("--model-workers", type=int, default=8)
    parser.add_argument("--sim-workers", type=int, default=12)
    parser.add_argument("--dry-run", action="store_true",
                        help="Print the fixed study plan without creating files or calling APIs.")
    cli = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]*", cli.tag):
        parser.error("--tag must be a simple directory name, not a path")
    if cli.model_workers < 1 or cli.sim_workers < 1:
        parser.error("worker counts must be positive")
    base = ROOT / "results" / cli.tag
    if base.exists():
        parser.error("results tag already exists; preserve it and choose a fresh --tag")
    frozen = check_frozen()
    args = SimpleNamespace(tag=cli.tag, overwrite=False, candidates=4,
                           max_tokens=16000, rod=True, tasks=list(ex.TASKS))
    jobs = [(model, task, run)
            for run in range(3) for task in ex.TASKS for model in ex.MODELS]
    random.Random(7409).shuffle(jobs)
    config = {
        "tag": cli.tag, "models": list(ex.MODELS), "tasks": list(ex.TASKS),
        "runs": 3, "candidates": 4, "max_tokens": 16000, "rod": True,
        "model_workers": cli.model_workers, "sim_workers": cli.sim_workers,
        "train_seeds": list(ex.TRAIN), "heldout_seeds": list(ex.TEST),
        "started_utc": now(), "fingerprint": ex.fingerprint(),
        "all_six_frozen_sha256": frozen,
        "driver": "run_experiment.py",
        "driver_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "scheduling": "all design searches, then all heldout conditions, then references",
        "queue_wait_timeouts": "ignored; underlying worker exceptions propagate",
        "planned_api_calls": 216,
    }
    if cli.dry_run:
        print(json.dumps(config, indent=2))
        return

    # Reuse packaged nominal images; render missing images with the frozen simulator.
    # These are observations, not additional training episodes or reference examples.
    import sim
    initial_dir = ROOT / "media" / "initial"
    initial_dir.mkdir(parents=True, exist_ok=True)
    initial_images = {}
    for task in ex.TASKS:
        for camera, suffix in [("overview", ""), ("overhead", "_overhead")]:
            path = initial_dir / (task + suffix + ".png")
            if not path.exists():
                sim.render_initial(task, str(path), seed=0, camera=camera)
            initial_images[path.name] = hashlib.sha256(path.read_bytes()).hexdigest()
    config["initial_image_sha256"] = initial_images
    base.mkdir(parents=True, exist_ok=False)
    ex.dump(base / "config.json", config)
    errors = []

    try:
        with cf.ProcessPoolExecutor(max_workers=cli.sim_workers,
                                    mp_context=mp.get_context("spawn")) as actual:
            pool = WaitingPool(actual)
            # No heldout work is submitted while any model is still searching.
            with cf.ThreadPoolExecutor(max_workers=cli.model_workers) as threads:
                futures = {threads.submit(ex.search, *job, pool, args): job for job in jobs}
                for future in cf.as_completed(futures):
                    try:
                        future.result()
                    except Exception as error:
                        errors.append({"phase": "search", "job": futures[future],
                                       "error": str(error),
                                       "traceback": traceback.format_exc()})
            check_frozen()
            errors.extend({"phase": "search_infrastructure", **error}
                          for error in infrastructure_errors(base))
            ex.dump(base / "errors.json", errors)
            if errors:
                raise RuntimeError("Search phase has infrastructure failures; records preserved. "
                                   "Do not silently retry or treat them as model failures.")
            print("ALL_DESIGN_SEARCHES_COMPLETE", flush=True)

            with cf.ThreadPoolExecutor(max_workers=cli.model_workers) as threads:
                futures = {}
                for model, task, run in jobs:
                    selection_path = (base / "search" / model / task
                                      / f"run_{run}" / "selected.json")
                    selection = json.loads(selection_path.read_text())
                    futures[threads.submit(ex.heldout, selection, pool, args)] = (
                        model, task, run)
                for future in cf.as_completed(futures):
                    try:
                        future.result()
                    except Exception as error:
                        errors.append({"phase": "heldout", "job": futures[future],
                                       "error": str(error),
                                       "traceback": traceback.format_exc()})
            check_frozen()
            ex.dump(base / "errors.json", errors)
            if errors:
                raise RuntimeError("Heldout phase failed; records preserved for audit.")
            print("ALL_HELDOUT_REPLAYS_COMPLETE", flush=True)
            ex.references(pool, args)
        check_frozen()
        subprocess.run([sys.executable, str(ROOT / "verify_dataset.py"),
                        "--tag", cli.tag], check=True)
        ex.dump(base / "completion.json", {
            "completed_utc": now(), "searches": 54, "candidates": 216,
            "heldout_rows": 2160, "control_rows": 120,
            "residual_infrastructure_errors": 0,
            "all_six_frozen_sha256": frozen,
            "driver_sha256": config["driver_sha256"],
        })
        print("EXPERIMENT_COMPLETE", flush=True)
    except Exception as error:
        ex.dump(base / "driver_failure.json", {
            "utc": now(), "error": str(error),
            "traceback": traceback.format_exc(),
            "instruction": "Preserve this dataset. Any recovery needs a separate, "
                           "outcome-independent registry and equal-budget searches.",
        })
        raise


if __name__ == "__main__":
    main()
