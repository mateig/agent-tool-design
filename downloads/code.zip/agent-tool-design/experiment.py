"""Fixed-budget, resumable remote model comparison. Run only after protocol freeze."""
import os
os.environ.setdefault("MUJOCO_GL","egl")
os.environ.setdefault("OPENBLAS_NUM_THREADS","1")
os.environ.setdefault("OMP_NUM_THREADS","1")
import json,time,pathlib,hashlib,traceback,argparse,concurrent.futures as cf,copy,random,sys
from api import call,extract_json,MODELS
ROOT=pathlib.Path(__file__).resolve().parent
TASKS=["tunnel_retrieval","plate_lifting","ball_transfer","recessed_knob","two_buttons","door_prop"]
TRAIN=[0,1,2]; TEST=list(range(100,110))
SYSTEM="""You are a robot tool-design agent participating in a controlled manipulation experiment.
Invent one physically connected rigid tool and an open-loop Cartesian motion program for the specified task.
Output ONLY a single JSON object with keys "reasoning" (brief physical explanation), "tool" (list of geometry objects), and "actions" (list of waypoints).
All geometry uses SI metres, relative tool-mount coordinates. Box sizes are HALF-extents; cylinders and capsules use [radius,half-length] aligned along local z, spheres [radius]. Quaternions are [w,x,y,z].
Default tool orientation is world identity. Each waypoint is an absolute WORLD mount position, not the tip position. Orientations are absolute, not relative.
The tool begins attached at the mount; the Panda hand is bulky. Use connected stems to keep the hand above guards, roofs, and trays. Tool components must form one connected physical assembly touching the mount.
Only contact, gravity, springs and robot actuation move objects. Do not rely on body teleportation, magic grasping, invisible disconnected parts, initial overlap, mesh changes, or physics exploits.
You have the nominal scene specification and initial image. Hidden evaluations use the same small perturbation distribution, with NO adaptation during a rollout.
You may revise after simulator feedback. You have four candidate submissions total in this independent search. Every candidate counts, even invalid geometry/action output.
Be careful about action interpolation, approach collision, joints, springs and target retention. Keep slow controlled motion, then hold the task condition through final settling.
Do not include markdown, analysis outside JSON, or additional fields."""
def dump(p,x):
 p=pathlib.Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 tmp=p.with_suffix(p.suffix+".tmp")
 tmp.write_text(json.dumps(x,indent=2,allow_nan=False,default=lambda o:o.item() if hasattr(o,"item") else str(o)));tmp.replace(p)
def fingerprint():
 return {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [ROOT/"sim.py",ROOT/"tasks_a.py",ROOT/"tasks_b.py",ROOT/"api.py",ROOT/"experiment.py"]}
def eval_worker(task,design,seed,trace=None,video=None):
 import sim
 try:return sim.evaluate(task,design,seed=seed,video_path=video,trajectory_path=trace)
 except Exception as e:return {"success":False,"score":0.,"violations":["evaluation exception: "+str(e)],"task_metrics":{},"traceback":traceback.format_exc()}
def contact_sheet_worker(task,design,tracepath,outpath):
 """Renders already-recorded states for feedback only; not used to compute success."""
 import sim,mujoco,numpy as np
 from PIL import Image,ImageDraw
 tr=json.loads(pathlib.Path(tracepath).read_text()).get("trajectory",[])
 if not tr:return None
 m,d,state,sid,xml=sim.build(task,design,0)
 renderer=mujoco.Renderer(m,360,480)
 canvas=Image.new("RGB",(480*3,392*2),(245,245,245));draw=ImageDraw.Draw(canvas)
 ix=np.linspace(0,len(tr)-1,6).astype(int)
 for k,j in enumerate(ix):
  rec=tr[int(j)];d.qpos[:]=rec["qpos"];mujoco.mj_forward(m,d)
  renderer.update_scene(d,camera="overview")
  im=Image.fromarray(renderer.render());x=(k%3)*480;y=(k//3)*392
  canvas.paste(im,(x,y));draw.text((x+8,y+365),f"t={rec['time']:.2f}s",(10,10,10))
 renderer.close();canvas.save(outpath);return str(outpath)
def ranking(results):
 return (sum(bool(r.get("success")) for r in results),sum(not bool(r.get("violations")) for r in results),sum(float(r.get("score",0)) if not r.get("violations") else 0 for r in results)/max(1,len(results)))
def search(model,task,run,pool,args):
 import sim
 folder=ROOT/"results"/args.tag/"search"/model/task/f"run_{run}"
 folder.mkdir(parents=True,exist_ok=True)
 selectedfile=folder/"selected.json"
 if selectedfile.exists() and not args.overwrite:return json.loads(selectedfile.read_text())
 spec=sim.task_spec(task,0);basehash=fingerprint()
 initial=ROOT/"media"/"initial"/(task+".png")
 observations=f"Independent design search run {run}. Solve this task:\n"+json.dumps(spec,indent=2)
 history=[];candidates=[];overhead=ROOT/"media"/"initial"/(task+"_overhead.png")
 baseimages=[str(p) for p in (initial,overhead) if p.exists()]
 images=baseimages.copy()
 for attempt in range(args.candidates):
  candidatefile=folder/f"candidate_{attempt}.json"
  if candidatefile.exists() and not args.overwrite:
   record=json.loads(candidatefile.read_text());candidates.append(record);history.append(record)
   if record.get("feedback_image") and pathlib.Path(record["feedback_image"]).exists():images=baseimages+[record["feedback_image"]]
   continue
  user=observations+"\n\nSubmission "+str(attempt+1)+f"/{args.candidates}."
  if history:
   user+="\nPrevious proposals and simulator feedback:\n"+json.dumps([{"candidate":j+1,"proposal":r.get("proposal"),"results":r.get("train_results"),"parse_error":r.get("parse_error")} for j,r in enumerate(history)],indent=2)
   user+="\nThe last image, if present, is a time-labelled contact sheet of your previous nominal rollout. Diagnose the failure and return a complete revised JSON proposal."
  record={"model":model,"task":task,"run":run,"attempt":attempt,"created_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"fingerprint":basehash,"system":SYSTEM,"prompt":user,"images":[{"path":p,"sha256":hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()} for p in images]}
  try:
   response=call(model,SYSTEM,user,images=images,max_tokens=args.max_tokens,effort="high");record["api"]=response
   dump(folder/f"candidate_{attempt}_api.json",record)
   proposal=extract_json(response["text"]);record["proposal"]=proposal
   trace=str(folder/f"candidate_{attempt}_trace.json")
   futures=[pool.submit(eval_worker,task,proposal,s,trace if s==0 else None) for s in TRAIN]
   results=[f.result(timeout=240) for f in futures];record["train_results"]=results
   sheet=str(folder/f"candidate_{attempt}_feedback.png")
   if pathlib.Path(trace).exists():
    try:
     image=pool.submit(contact_sheet_worker,task,proposal,trace,sheet).result(timeout=120)
     record["feedback_image"]=image
    except Exception as e:record["render_error"]=str(e)
  except Exception as e:
   record["parse_error"]=type(e).__name__+": "+str(e)
   record["train_results"]=[{"success":False,"score":0,"violations":[record["parse_error"]],"task_metrics":{}} for s in TRAIN]
  if fingerprint()!=basehash:raise RuntimeError("Frozen simulator or harness changed during search")
  dump(candidatefile,record);candidates.append(record);history.append(record)
  if record.get("feedback_image"):images=baseimages+[record["feedback_image"]]
  print(json.dumps({"event":"candidate_done","model":model,"task":task,"run":run,"attempt":attempt,"train_success":ranking(record["train_results"])[0],"invalid":bool(record.get("parse_error"))}),flush=True)
 best=max(candidates,key=lambda r:ranking(r.get("train_results",[])))
 selection={"model":model,"task":task,"run":run,"selected_attempt":best["attempt"],"proposal":best.get("proposal",{"tool":[],"actions":[]}),"train_rank":ranking(best.get("train_results",[])),"candidate_count":len(candidates),"fingerprint":basehash}
 dump(selectedfile,selection)
 return selection
def heldout(selection,pool,args):
 model,task,run=selection["model"],selection["task"],selection["run"]
 path=ROOT/"results"/args.tag/"heldout"/model/task/f"run_{run}.json"
 if path.exists() and not args.overwrite:return json.loads(path.read_text())
 design=selection["proposal"];controls={"invented_tool":design}
 firstpath=ROOT/"results"/args.tag/"search"/model/task/f"run_{run}"/"candidate_0.json"
 if firstpath.exists():
  first=json.loads(firstpath.read_text()).get("proposal",{"tool":[],"actions":[]})
  controls["first_candidate"]=first
 removed=copy.deepcopy(design);removed["tool"]=[];controls["tool_removed"]=removed
 if args.rod:
  rod=copy.deepcopy(design);rod["tool"]=[{"type":"box","pos":[0,0,-.10],"size":[.008,.008,.10]}];controls["generic_rod"]=rod
 futs=[(label,s,pool.submit(eval_worker,task,d,s)) for label,d in controls.items() for s in TEST]
 rows=[{"condition":label,"seed":s,**f.result(timeout=300)} for label,s,f in futs]
 result={"selection":selection,"rows":rows,"heldout_seeds":TEST,"fingerprint":fingerprint()}
 dump(path,result);print(json.dumps({"event":"heldout_done","model":model,"task":task,"run":run,"successes":{c:sum(r.get("success",False) for r in rows if r["condition"]==c) for c in controls}}),flush=True)
 return result
def references(pool,args):
 import sim
 rows=[]
 jobs=[]
 for task in args.tasks:
  for condition,design in [("reference",sim.reference(task)),("idle",{"tool":[],"actions":[]})]:
   for seed in TEST:jobs.append((task,condition,seed,pool.submit(eval_worker,task,design,seed)))
 for task,condition,seed,f in jobs:rows.append({"task":task,"condition":condition,"seed":seed,**f.result(timeout=300)})
 dump(ROOT/"results"/args.tag/"controls.json",{"rows":rows,"fingerprint":fingerprint()});return rows
def main():
 p=argparse.ArgumentParser();p.add_argument("--models",nargs="+",default=list(MODELS));p.add_argument("--tasks",nargs="+",default=TASKS);p.add_argument("--runs",type=int,default=3);p.add_argument("--candidates",type=int,default=4);p.add_argument("--max-tokens",type=int,default=16000);p.add_argument("--model-workers",type=int,default=12);p.add_argument("--sim-workers",type=int,default=18);p.add_argument("--tag",default="main_v1");p.add_argument("--rod",action="store_true");p.add_argument("--overwrite",action="store_true");p.add_argument("--controls-only",action="store_true");args=p.parse_args()
 (ROOT/"results"/args.tag).mkdir(exist_ok=True,parents=True)
 dump(ROOT/"results"/args.tag/"config.json",{**vars(args),"fingerprint":fingerprint(),"train_seeds":TRAIN,"heldout_seeds":TEST,"started_utc":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime())})
 import multiprocessing as mp
 with cf.ProcessPoolExecutor(max_workers=args.sim_workers,mp_context=mp.get_context("spawn")) as pool:
  if args.controls_only:references(pool,args);return
  jobs=[(m,t,r) for r in range(args.runs) for t in args.tasks for m in args.models]
  random.Random(7409).shuffle(jobs)
  errors=[]
  def worker(job):
   sel=search(*job,pool,args);return heldout(sel,pool,args)
  with cf.ThreadPoolExecutor(max_workers=args.model_workers) as ex:
   futures={ex.submit(worker,j):j for j in jobs}
   for f in cf.as_completed(futures):
    try:f.result()
    except Exception as e:
     error={"job":futures[f],"error":str(e),"traceback":traceback.format_exc()};errors.append(error);print(json.dumps({"event":"job_error",**error}),flush=True)
  references(pool,args);dump(ROOT/"results"/args.tag/"errors.json",errors)
 print("EXPERIMENT_COMPLETE",flush=True)
if __name__=="__main__":main()

