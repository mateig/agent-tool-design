# Can Frontier Agents Invent Robot Tools?

Matei Gardea
Department of Electrical Engineering and Computer Sciences
University of California, Berkeley

Project: https://mateig.github.io/agent-tool-design/

This release contains the simulator and experiment source, Franka Panda assets,
45 selected tool/motion designs, their recorded evaluation results, five-task
analysis data, and the paper's LaTeX sources. The five reported tasks are listed
in reported_tasks.json. The frozen source retains the original task definitions;
the reported task subset and its exclusion history are documented in
analysis/five_task/scope.json.

## Reproduce the reported averages

This calculation uses only Python's standard library:

    python3 report_results.py

## Replay a selected tool

Create an environment and install the recorded dependency versions:

    python3 -m venv .venv
    . .venv/bin/activate
    pip install -r requirements.txt

On a machine with EGL rendering support:

    python sim.py tunnel_retrieval --design selected/sol__tunnel_retrieval__run0.json --seed 100 --video rollout.mp4

The replay command returns the original simulator outcome. Reported success
rates use the retained outcomes in analysis/five_task/validated_trials.csv.
The exact scoring protocol is in analysis/five_task/scoring_protocol.txt.
Sensitivity and released-door evaluations are implemented in sensitivity.py
and collision_audit.py.

## Source and assets

experiment.py contains the model prompt, four-attempt design procedure,
selection rule, and held-out replay logic. api.py supports OPENAI_API_KEY and
ANTHROPIC_API_KEY environment variables for fresh model calls. Replaying a
selected design requires no model API key.

The original experiment harness includes the original task suite. Use
reported_tasks.json to select the five tasks in the paper. Original frozen
sources are preserved rather than edited to change the study retrospectively.

See SOURCE_NOTES.md and menagerie/franka_emika_panda/LICENSE for source and
asset attribution. Credentials and the Python environment are excluded.
