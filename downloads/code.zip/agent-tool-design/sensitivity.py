"""Predeclared conservative sensitivity: main pass AND 1ms pass AND <=5mm allstep penetration."""
import os
os.environ.setdefault("MUJOCO_GL","egl");os.environ.setdefault("OPENBLAS_NUM_THREADS","1");os.environ.setdefault("OMP_NUM_THREADS","1")
import json,pathlib,concurrent.futures as cf,argparse,hashlib,time
ROOT=pathlib.Path(__file__).resolve().parent
def worker(task,design,seed):
 import sim
 r=sim.evaluate(task,design,seed=seed,timestep=.001)
 r["strict_success"]=bool(r.get("success")) and r.get("physics",{}).get("max_all_contact_penetration",float("inf"))<=.005
 return r
def dump(p,x):
 p.parent.mkdir(exist_ok=True,parents=True);tmp=p.with_suffix(".tmp");tmp.write_text(json.dumps(x,indent=2));tmp.replace(p)
def main():
 p=argparse.ArgumentParser();p.add_argument("--tag",default="main_v1");p.add_argument("--workers",type=int,default=18);a=p.parse_args()
 base=ROOT/"results"/a.tag;out=base/"sensitivity";out.mkdir(exist_ok=True)
 jobs=[]
 for path in base.glob("heldout/*/*/run_*.json"):
  h=json.loads(path.read_text());sel=h["selection"];m,t,run=sel["model"],sel["task"],sel["run"]
  des=sel["proposal"];controls={"invented_tool":des}
  from copy import deepcopy
  no=deepcopy(des);no["tool"]=[];controls["tool_removed"]=no
  rod=deepcopy(des);rod["tool"]=[{"type":"box","pos":[0,0,-.10],"size":[.008,.008,.10]}];controls["generic_rod"]=rod
  f=base/"search"/m/t/f"run_{run}"/"candidate_0.json"
  controls["first_candidate"]=json.loads(f.read_text()).get("proposal",{"tool":[],"actions":[]})
  for row in h["rows"]:
   key=f"{m}__{t}__{run}__{row['condition']}__{row['seed']}";p=out/(key+".json")
   meta={"model":m,"task":t,"run":run,"condition":row["condition"],"seed":row["seed"],"main_success":bool(row.get("success")),"main_max_penetration":row.get("physics",{}).get("max_all_contact_penetration")}
   if p.exists():continue
   if not meta["main_success"]:
    dump(p,{**meta,"strict_success":False,"rerun":False,"reason":"Main-gate failure excluded from conservative joint criterion"});continue
   jobs.append((p,meta,controls[row["condition"]]))
 import multiprocessing as mp
 with cf.ProcessPoolExecutor(max_workers=a.workers,mp_context=mp.get_context("spawn")) as ex:
  futs={ex.submit(worker,meta["task"],des,meta["seed"]):(p,meta) for p,meta,des in jobs}
  for f in cf.as_completed(futs):
   p,meta=futs[f]
   try:r=f.result();dump(p,{**meta,"strict_success":r["strict_success"],"rerun":True,"result":r})
   except Exception as e:dump(p,{**meta,"strict_success":False,"rerun":True,"error":str(e)})
 rows=[json.loads(p.read_text()) for p in out.glob("*.json") if p.name!="summary.json"]
 summary={"criterion":"main 2ms pass AND replaysuccess at1ms AND every-step allcontact penetration<=5mm; failures not rerun","rows":len(rows),"models":{}}
 for m in ["astra","sol","opus"]:
  summary["models"][m]={}
  for cond in ["invented_tool","first_candidate","tool_removed","generic_rod"]:
   rr=[r for r in rows if r["model"]==m and r["condition"]==cond]
   summary["models"][m][cond]={"main_successes":sum(r["main_success"] for r in rr),"strict_successes":sum(r["strict_success"] for r in rr),"n":len(rr),"by_task":{}}
   for task in ["tunnel_retrieval","plate_lifting","ball_transfer","recessed_knob","two_buttons","door_prop"]:
    tt=[r for r in rr if r["task"]==task];summary["models"][m][cond]["by_task"][task]={"main_successes":sum(r["main_success"] for r in tt),"strict_successes":sum(r["strict_success"] for r in tt),"n":len(tt)}
 dump(out/"summary.json",summary);print(json.dumps(summary,indent=2))
if __name__=="__main__":main()

