"""Contact-based Panda rigid-tool bench. All SI units, quaternions wxyz."""
import os
os.environ.setdefault("MUJOCO_GL","egl")
import json, time, math, copy
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
import mujoco
from scipy.spatial.transform import Rotation, Slerp
ROOT=Path(__file__).resolve().parent
TABLE=.04
START=np.array([.35,0,.45])
HOME=np.array([0,-.5,0,-2.0,0,1.6,.785398])
TASKS=["tunnel_retrieval","plate_lifting","ball_transfer","recessed_knob","two_buttons","door_prop"]
def vec(x): return " ".join(str(float(v)) for v in x)
def rot(q): return Rotation.from_quat(np.asarray(q)[[1,2,3,0]])
def wquat(r): return r.as_quat()[[3,0,1,2]]
def module(task):
 import tasks_a, tasks_b
 return tasks_a if task in TASKS[:3] else tasks_b

def task_spec(task,seed=0):
 s=module(task).spec(task,seed)
 s.pop("hint",None)
 s.update({"coordinate_frame":"world xyz metres; table top z=0.04; tool mount orientation identity at default quat [1,0,0,0]","initial_mount_pos":START.tolist(),"tool_schema":"tool: list of {type: box|sphere|cylinder|capsule, pos:[x,y,z] relative to mount, size:[half extents] (sphere radius; cylinder/capsule radius,half-length), quat:[w,x,y,z] optional}","action_schema":"actions: list of {pos:[world x,y,z], quat:[w,x,y,z] optional default identity, duration: seconds [0.1,6], gripper:0 closed..1 open optional, release_tool:bool optional irreversible}","limits":{"connectivity":"Every primitive must connect to the mount region (radius8mm) through other primitives; exact surface gap tolerance2mm.","max_geoms":32,"max_actions":60,"max_duration":90,"tool_local_extent":.42,"geom_min_size":.001,"geom_max_size":.24,"mount_workspace":[[.18,.85],[-.5,.5],[.055,.75]]},"execution":"Tool starts rigidly attached to Panda hand. Contact physics with joint position actuators; Cartesian waypoints interpolated using IK. No grasp assistance or object teleportation. Release_tool detaches the complete rigid tool. Success assessed from physical object states."})
 return s

def reference(task): return module(task).reference(task)
def connected_tool(gs):
 # Use exact MuJoCo convex primitive distances, including a physical 8mm-radius mount region.
 root=ET.Element("mujoco");world=ET.SubElement(root,"worldbody")
 ET.SubElement(world,"geom",name="mount",type="sphere",size=".008",contype="0",conaffinity="0")
 for i,g in enumerate(gs):
  ET.SubElement(world,"geom",name="g"+str(i),type=g["type"],pos=vec(g.get("pos",[0,0,0])),size=vec(g["size"]),quat=vec(g.get("quat",[1,0,0,0])),contype="0",conaffinity="0")
 m=mujoco.MjModel.from_xml_string(ET.tostring(root,encoding="unicode"));d=mujoco.MjData(m);mujoco.mj_forward(m,d)
 reached={0}
 while True:
  new={i for i in range(1,len(gs)+1) if i not in reached and any(mujoco.mj_geomDistance(m,d,i,j,.003,None)<=.002 for j in reached)}
  if not new:break
  reached|=new
 return len(reached)==len(gs)+1

def validate(design):
 errors=[]
 gs=design.get("tool",[])
 if isinstance(gs,dict): gs=gs.get("geoms",[])
 if len(gs)>32: errors.append("more than 32 tool geoms")
 for g in gs:
  typ=g.get("type")
  n={"box":3,"sphere":1,"cylinder":2,"capsule":2}.get(typ)
  if n is None: errors.append("unsupported tool geometry"); continue
  sz=np.asarray(g.get("size",[]),float)
  p=np.asarray(g.get("pos",[0,0,0]),float)
  if sz.shape!=(n,) or not np.all(np.isfinite(sz)) or np.any(sz<.001) or np.any(sz>.24): errors.append("invalid tool size")
  if p.shape!=(3,) or not np.all(np.isfinite(p)): errors.append("invalid tool position")
  q=np.asarray(g.get("quat",[1,0,0,0]),float)
  if q.shape!=(4,) or not np.all(np.isfinite(q)) or abs(np.linalg.norm(q)-1)>.02: errors.append("invalid quaternion")
  elif p.shape==(3,) and sz.shape==(n,) and np.all(np.isfinite(p)) and np.all(np.isfinite(sz)):
   R=rot(q).as_matrix();axis=np.abs(R[:,2])
   if typ=="box":extent=np.abs(R)@sz
   elif typ=="sphere":extent=np.repeat(sz[0],3)
   elif typ=="cylinder":extent=sz[0]*np.sqrt(np.maximum(0,1-axis**2))+sz[1]*axis
   else:extent=np.repeat(sz[0],3)+sz[1]*axis
   if np.any(np.abs(p)+extent>.42000001):errors.append("tool exceeds exact primitive local extent")
 if not errors and gs and not connected_tool(gs):errors.append("tool is disconnected from mount or has disconnected components (primitive surface gap >2mm)")
 acts=design.get("actions",[])
 if len(acts)>60: errors.append("more than 60 actions")
 total=0
 for a in acts:
  p=np.asarray(a.get("pos",[]),float)
  if p.shape!=(3,) or not np.all(np.isfinite(p)) or np.any(p<np.array([.18,-.5,.055])) or np.any(p>np.array([.85,.5,.75])): errors.append("action outside mount workspace")
  dur=float(a.get("duration",1));total+=dur
  if not np.isfinite(dur) or not .1<=dur<=6: errors.append("invalid duration")
  q=np.asarray(a.get("quat",[1,0,0,0]),float)
  if q.shape!=(4,) or not np.all(np.isfinite(q)) or abs(np.linalg.norm(q)-1)>.02: errors.append("invalid action quaternion")
 if total>90: errors.append("duration exceeds 90s")
 return list(dict.fromkeys(errors))

def build(task,design,seed=0,timestep=.002):
 tree=ET.parse(ROOT/"menagerie/franka_emika_panda/panda.xml");root=tree.getroot()
 root.find("compiler").set("meshdir",str(ROOT/"menagerie/franka_emika_panda/assets"))
 opt=root.find("option");opt.set("timestep",str(float(timestep)));opt.set("gravity","0 0 -9.81")
 ET.SubElement(root,"size",njmax="4000",nconmax="1000")
 root.remove(root.find("keyframe"))
 visual=ET.SubElement(root,"visual");ET.SubElement(visual,"global",offwidth="960",offheight="720");ET.SubElement(visual,"map",znear="0.01")
 world=root.find("worldbody")
 ET.SubElement(world,"geom",name="ground",type="plane",size="2 2 .1",rgba=".18 .21 .25 1",contype="1",conaffinity="1")
 ET.SubElement(world,"geom",name="table",type="box",pos=".6 0 .02",size=".45 .55 .02",rgba=".65 .68 .7 1",friction=".7 .005 .0001")
 ET.SubElement(world,"light",pos=".5 -.5 2",dir="0 0 -1",diffuse=".8 .8 .8")
 ET.SubElement(world,"camera",name="overview",pos=".05 -1.35 .95",xyaxes=".949 -.316 0 .169 .507 .845")
 ET.SubElement(world,"camera",name="overhead",pos=".55 0 1.25",xyaxes="1 0 0 0 1 0")
 ET.SubElement(world,"camera",name="close",pos="1.15 -.95 .75",xyaxes=".72 .69 0 -.28 .29 .91")
 hand=world.find(".//body[@name=\"hand\"]")
 ET.SubElement(hand,"site",name="tool_mount",pos="0 0 .107",quat="0 1 0 0",size=".006",rgba=".9 .1 .1 1")
 gs=design.get("tool",[])
 if isinstance(gs,dict):gs=gs.get("geoms",[])
 tool=None
 if gs:
  tool=ET.SubElement(world,"body",name="tool",pos=vec(START))
  ET.SubElement(tool,"freejoint",name="tool_free")
  for i,g in enumerate(gs):
   ET.SubElement(tool,"geom",name=f"tool_{i}",type=g["type"],pos=vec(g.get("pos",[0,0,0])),size=vec(g["size"]),quat=vec(g.get("quat",[1,0,0,0])),rgba=".98 .52 .08 1",density="400",friction=".8 .005 .0001",solref=".008 1")
  ET.SubElement(root.find("equality"),"weld",name="tool_weld",body1="hand",body2="tool",relpose="0 0 .107 0 1 0 0",solref=".004 1")
  for b in ["hand","left_finger","right_finger"]: ET.SubElement(root.find("contact"),"exclude",body1=b,body2="tool")
 state=module(task).build(task,world,seed)
 xml=ET.tostring(root,encoding="unicode")
 model=mujoco.MjModel.from_xml_string(xml);data=mujoco.MjData(model)
 data.qpos[:7]=HOME;data.qpos[7:9]=.04;data.ctrl[:7]=HOME;data.ctrl[7]=255
 sid=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_SITE,"tool_mount")
 ikd=mujoco.MjData(model);ikd.qpos[:]=data.qpos
 q,err=ik(model,ikd,START,[1,0,0,0],HOME,sid)
 data.qpos[:7]=q;data.ctrl[:7]=q
 mujoco.mj_forward(model,data)
 if tool is not None:
  j=model.joint("tool_free").qposadr[0]
  data.qpos[j:j+3]=data.site_xpos[sid]
  data.qpos[j+3:j+7]=wquat(Rotation.from_matrix(data.site_xmat[sid].reshape(3,3)))
  mujoco.mj_forward(model,data)
 return model,data,state,sid,xml

def ik(model,data,pos,quat,qseed,sid):
 data.qpos[:7]=qseed
 targetR=rot(quat)
 jacp=np.zeros((3,model.nv));jacr=np.zeros((3,model.nv))
 for _ in range(65):
  mujoco.mj_forward(model,data)
  ep=np.asarray(pos)-data.site_xpos[sid]
  er=(targetR*Rotation.from_matrix(data.site_xmat[sid].reshape(3,3)).inv()).as_rotvec()
  e=np.r_[ep,er*.35]
  if np.linalg.norm(e)<.0004:break
  mujoco.mj_jacSite(model,data,jacp,jacr,sid)
  J=np.vstack([jacp[:,:7],.35*jacr[:,:7]])
  dq=J.T@np.linalg.solve(J@J.T+.0002*np.eye(6),e)
  data.qpos[:7]+=np.clip(dq,-.12,.12)
  data.qpos[:7]=np.clip(data.qpos[:7],model.jnt_range[:7,0]+.003,model.jnt_range[:7,1]-.003)
 return data.qpos[:7].copy(),float(np.linalg.norm(ep))

def measure(task,m,d,state):return module(task).measure(task,m,d,state)

def evaluate(task,design,seed=0,video_path=None,trajectory_path=None,timestep=.002):
 start=time.monotonic();violations=validate(design)
 if violations:return {"success":False,"score":0.,"violations":violations,"task_metrics":{},"walltime":time.monotonic()-start}
 try:m,d,state,sid,xml=build(task,design,seed,timestep=timestep)
 except Exception as e:return {"success":False,"score":0.,"violations":["build: "+str(e)],"task_metrics":{},"walltime":time.monotonic()-start}
 renderer=None;writer=None;frames=0
 if video_path:
  import imageio.v2 as imageio
  Path(video_path).parent.mkdir(parents=True,exist_ok=True)
  renderer=mujoco.Renderer(m,480,640);writer=imageio.get_writer(str(video_path),fps=25,codec="libx264",quality=7)
 ikd=mujoco.MjData(m);ikd.qpos[:]=d.qpos
 prevp=START.copy();prevq=np.array([1.,0,0,0]);qgoal=d.qpos[:7].copy()
 dt=float(m.opt.timestep);ik_period=max(1,round(.01/dt));sample_period=max(1,round(.04/dt))
 tracking=[];ikerrors=[];trajectory=[];maxvel=0.;nsteps=0;released=False
 metrics=measure(task,m,d,state)
 tool_geoms={i for i in range(m.ngeom) if m.geom_bodyid[i]==mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,"tool")}
 maxpenetration=0.;maxglobalpenetration=0.;maxforce=0.;maxweld=0.;contact_count=0
 for c in d.contact:
  if (c.geom1 in tool_geoms)!=(c.geom2 in tool_geoms) and c.dist<-.002:violations.append("initial tool penetration exceeds 2mm")
 def monitor():
  nonlocal maxpenetration,maxglobalpenetration,maxforce,maxweld,contact_count
  cf=np.zeros(6)
  for ci,c in enumerate(d.contact):
   maxglobalpenetration=max(maxglobalpenetration,float(-c.dist))
   if (c.geom1 in tool_geoms)!=(c.geom2 in tool_geoms):
    contact_count+=1;maxpenetration=max(maxpenetration,float(-c.dist));mujoco.mj_contactForce(m,d,ci,cf);maxforce=max(maxforce,float(np.linalg.norm(cf[:3])))
  if tool_geoms and not released:maxweld=max(maxweld,float(np.linalg.norm(d.xpos[m.body("tool").id]-d.site_xpos[sid])))
 def sample():
  nonlocal metrics,frames
  metrics=measure(task,m,d,state)
  trajectory.append({"time":round(d.time,4),"mount":d.site_xpos[sid].tolist(),"qpos":d.qpos.tolist(),"metrics":metrics})
  if renderer:
   renderer.update_scene(d,camera="overview");writer.append_data(renderer.render());frames+=1
 try:
  for a in design.get("actions",[]):
   if a.get("release_tool") and mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_EQUALITY,"tool_weld")>=0:
    d.eq_active[m.equality("tool_weld").id]=0;released=True;state["tool_released"]=True
   target=np.asarray(a["pos"],float);tq=np.asarray(a.get("quat",[1,0,0,0]),float)
   slerp=Slerp([0,1],Rotation.concatenate([rot(prevq),rot(tq)]))
   steps=max(1,round(float(a.get("duration",1))/dt))
   for k in range(steps):
    alpha=(k+1)/steps
    # Quintic time law limits impulsive starts at each waypoint.
    h=alpha**3*(10-15*alpha+6*alpha**2)
    desired=prevp+(target-prevp)*h
    if k%ik_period==0:
     quat=wquat(slerp(h));qgoal,err=ik(m,ikd,desired,quat,qgoal,sid);ikerrors.append(err)
    d.ctrl[:7]=qgoal;d.ctrl[7]=255*float(a.get("gripper",1))
    mujoco.mj_step(m,d);nsteps+=1
    monitor()
    maxvel=max(maxvel,float(np.max(np.abs(d.qvel))))
    if nsteps%sample_period==0:
     tracking.append(float(np.linalg.norm(d.site_xpos[sid]-desired)));sample()
    if not np.all(np.isfinite(d.qpos)):raise RuntimeError("nonfinite simulation state")
   prevp=target;prevq=tq
  # One second of free settling; actuators retain final pose.
  for k in range(round(1/dt)):
   mujoco.mj_step(m,d);nsteps+=1
   monitor()
   if nsteps%sample_period==0:sample()
  sample()
 except Exception as e:violations.append("runtime: "+str(e))
 finally:
  if writer:writer.close()
  if renderer:renderer.close()
 if trajectory_path:
  Path(trajectory_path).parent.mkdir(parents=True,exist_ok=True);Path(trajectory_path).write_text(json.dumps({"task":task,"seed":seed,"design":design,"trajectory":trajectory},indent=2))
 warning_counts={}
 for name in ["BADQPOS","BADQVEL","BADQACC","BADCTRL"]:
  count=int(d.warning[getattr(mujoco.mjtWarning,"mjWARN_"+name)].number)
  warning_counts[name]=count
  if count:violations.append("MuJoCo numerical warning "+name)
 time_mismatch=abs(float(d.time)-nsteps*dt)
 if time_mismatch>dt*1.05:violations.append("simulation time mismatch indicates numerical reset")
 if maxglobalpenetration>.01:violations.append("contact penetration exceeds 10mm")
 if tracking and max(tracking)>.1:violations.append("mount tracking error exceeds 10cm")
 if ikerrors and max(ikerrors)>.04:violations.append("unreachable waypoint: IK error exceeds 4cm")
 result={"success":bool(metrics.get("success",False)) and not violations,"score":float(metrics.get("score",float(metrics.get("success",False)))),"task_metrics":metrics,"violations":violations,"tracking_error":{"mean":float(np.mean(tracking)) if tracking else 0,"max":float(max(tracking,default=0)),"ik_max":float(max(ikerrors,default=0))},"physics":{"tool_mass":float(m.body_mass[m.body("tool").id]) if tool_geoms else 0.,"max_all_contact_penetration":maxglobalpenetration,"monitor_hz":1/dt,"timestep":dt,"warning_counts":warning_counts,"time_mismatch":time_mismatch,"max_tool_penetration":maxpenetration,"max_tool_contact_force":maxforce,"max_weld_position_error":maxweld,"tool_contact_samples":contact_count},"sim_seconds":float(d.time),"max_velocity":maxvel,"tool_released":released,"seed":seed,"walltime":time.monotonic()-start}
 return result

def render_initial(task,path,seed=0,camera="overview"):
 m,d,state,sid,xml=build(task,{"tool":[],"actions":[]},seed)
 r=mujoco.Renderer(m,720,960);r.update_scene(d,camera=camera)
 from PIL import Image
 Image.fromarray(r.render()).save(path);r.close();return str(path)

if __name__=="__main__":
 import argparse
 p=argparse.ArgumentParser();p.add_argument("task",choices=TASKS);p.add_argument("--design");p.add_argument("--seed",type=int,default=0);p.add_argument("--video");p.add_argument("--trajectory");p.add_argument("--initial");args=p.parse_args()
 if args.initial:print(render_initial(args.task,args.initial,args.seed))
 else:
  design=json.loads(Path(args.design).read_text()) if args.design else reference(args.task)
  print(json.dumps(evaluate(args.task,design,args.seed,args.video,args.trajectory),indent=2))
