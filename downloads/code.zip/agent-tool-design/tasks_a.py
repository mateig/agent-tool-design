"""Three contact-only manipulation task scenes and preregistered predicates."""
import xml.etree.ElementTree as E
import numpy as np

def geom(w,name,typ,pos,size,**kw):
 return E.SubElement(w,"geom",name=name,type=typ,pos=" ".join(map(str,pos)),size=" ".join(map(str,size)),**{k:str(v) for k,v in kw.items()})
def free(w,name,pos,typ,size,mass,rgba):
 b=E.SubElement(w,"body",name=name,pos=" ".join(map(str,pos)));E.SubElement(b,"freejoint",name=name+"_free")
 geom(b,name+"_geom",typ,[0,0,0],size,mass=mass,rgba=rgba,friction=".65 .005 .0001",solref=".008 1")
 return b

def build(task,w,seed=0):
 rng=np.random.default_rng(seed);dx=float(rng.uniform(-.004,.004)) if seed else 0.;dy=float(rng.uniform(-.003,.003)) if seed else 0.
 if task=="tunnel_retrieval":
  # front opening x=.48, rear wall x=.75, 60 mm clearance.
  geom(w,"tunnel_roof","box",[.665,0,.111],[.135,.125,.011],rgba=".35 .45 .6 .75")
  for y in [-.12,.12]:geom(w,"tunnel_side"+str(y),"box",[.665,y,.075],[.135,.008,.035],rgba=".35 .45 .6 1")
  geom(w,"tunnel_back","box",[.805,0,.075],[.008,.128,.035],rgba=".35 .45 .6 1")
  free(w,"block",[.69+dx,dy,.059],"box",[.018,.018,.018],.055,".8 .16 .18 1")
  return {"dx":dx,"dy":dy,"threshold_x":.505,"initial_x":.69+dx,"last_time":0.,"hold_time":0.}
 if task=="plate_lifting":
  # Plate rests on four 7mm pads, leaving a narrow under-plate gap.
  for x in [.49,.61]:
   for y in [-.06,.06]:geom(w,f"pad{x}{y}","cylinder",[x,y,.0435],[.008,.0035],rgba=".25 .25 .25 1")
  free(w,"plate",[.55+dx,dy,.052],"box",[.083,.083,.005],.12,".15 .55 .85 1")
  return {"dx":dx,"dy":dy,"initial_z":.052,"max_height":.052,"hold_time":0.,"last_time":0.}
 if task=="ball_transfer":
  # Shallow source tray and taller receiving bin; no hidden grasp constraints.
  for label,cx,cy in [("source",.56,-.17),("target",.56,.19)]:
   wallh=.022 if label=="source" else .05
   geom(w,label+"_floor","box",[cx,cy,.043],[.105,.09,.003],rgba=".3 .42 .5 1")
   for sx in [-1,1]:
    hh=.004 if label=="source" and sx==-1 else wallh
    geom(w,label+"_x"+str(sx),"box",[cx+sx*.109,cy,.046+hh],[.004,.094,hh],rgba=".3 .42 .5 1")
   for sy in [-1,1]:geom(w,label+"_y"+str(sy),"box",[cx,cy+sy*.094,.046+wallh],[.113,.004,wallh],rgba=".3 .42 .5 1")
  for i,(x,y) in enumerate([(.535,-.19),(.58,-.19),(.555,-.145)]):free(w,"ball"+str(i),[x+dx,y+dy,.066],"sphere",[.019],.025,[".9 .2 .2 1",".2 .8 .3 1",".95 .8 .1 1"][i])
  return {"dx":dx,"dy":dy,"max_transferred":0,"last_time":0.,"hold_time":0.}
 raise KeyError(task)

def measure(task,m,d,state):
 if task=="tunnel_retrieval":
  p=d.xpos[m.body("block").id].copy();success=bool(p[0]<.505 and abs(p[1])<.2 and .045<p[2]<.15)
  dt=max(0,d.time-state["last_time"]);state["last_time"]=d.time
  speed=float(np.linalg.norm(d.qvel[m.joint("block_free").dofadr[0]:m.joint("block_free").dofadr[0]+3]))
  state["hold_time"]=state["hold_time"]+dt if success and speed<.03 else 0.
  success=success and state["hold_time"]>=.3
  return {"success":success,"block_speed":speed,"hold_seconds":state["hold_time"],"score":float(np.clip((state["initial_x"]-p[0])/(state["initial_x"]-.505),0,1)),"block_pos":p.tolist(),"required_x_below":.505}
 if task=="plate_lifting":
  p=d.xpos[m.body("plate").id].copy();dt=max(0,d.time-state["last_time"]);state["last_time"]=d.time
  state["max_height"]=max(state["max_height"],float(p[2]))
  if p[2]>.105 and .3<p[0]<.78 and abs(p[1])<.4:state["hold_time"]+=dt
  else:state["hold_time"]=0.
  success=bool(state["hold_time"]>=.4)
  return {"success":success,"score":float(np.clip((p[2]-.052)/(.105-.052),0,1)),"plate_pos":p.tolist(),"max_height":state["max_height"],"above_threshold_seconds":state["hold_time"]}
 if task=="ball_transfer":
  ps=[d.xpos[m.body("ball"+str(i)).id].copy() for i in range(3)]
  n=sum(bool(.455<p[0]<.665 and .1<p[1]<.28 and .046<p[2]<.16) for p in ps)
  state["max_transferred"]=max(state["max_transferred"],n)
  dt=max(0,d.time-state["last_time"]);state["last_time"]=d.time
  speed=max(float(np.linalg.norm(d.qvel[m.joint("ball"+str(i)+"_free").dofadr[0]:m.joint("ball"+str(i)+"_free").dofadr[0]+3])) for i in range(3))
  state["hold_time"]=state["hold_time"]+dt if n==3 and speed<.04 else 0.
  return {"success":n==3 and state["hold_time"]>=.3,"hold_seconds":state["hold_time"],"max_ball_speed":speed,"score":n/3.,"balls_in_target":n,"ball_positions":[p.tolist() for p in ps],"max_transferred":state["max_transferred"]}

def spec(task,seed=0):
 base={"task":task,"seed":seed,"randomization":"Evaluation seeds vary object xy by up to 4mm x and 3mm y; seed 0 nominal.","tools_preattached":True}
 if task=="tunnel_retrieval":base.update({"objective":"Pull the block out of the low tunnel. Final block center x<0.505, |y|<0.2, z in (.045,.15), speed<0.03m/s continuously for0.3s through completion.","scene":{"block_center":[.69,0,.059],"block_halfsize":[.018,.018,.018],"tunnel_front_x":.53,"tunnel_back_x":.797,"interior_y":[-.112,.112],"roof_bottom_z":.1,"floor_z":.04},"hint":"Only thin geometry fits inside the 60mm-high opening. Tunnel rear is closed."})
 if task=="plate_lifting":base.update({"objective":"Lift plate center above z=.105 for at least .4 continuous seconds through the final observation.","scene":{"plate_center":[.55,0,.052],"plate_halfsize":[.083,.083,.005],"plate_bottom_z":.047,"table_z":.04,"gap_m":.007,"support_pads":[[.49,-.06],[.49,.06],[.61,-.06],[.61,.06]]},"hint":"A thin fork or spatula may enter the 7mm gap from a side before lifting."})
 if task=="ball_transfer":base.update({"objective":"Move all three loose balls into receiving container; final centers x(.455,.665), y(.1,.28), z(.046,.16), all speeds<0.04m/s continuously for0.3s through completion.","scene":{"source_center":[.56,-.17],"target_center":[.56,.19],"source_floor_top":.046,"source_walls_top":.09,"source_front_lip_top":.054,"target_walls_top":.146,"interior_halfsize":[.105,.09],"ball_radius":.019,"ball_centers":[[.535,-.19,.066],[.58,-.19,.066],[.555,-.145,.066]]},"hint":"Compound tools may form scoops, cups, or forks. Moving balls requires actual contacts and gravity; no attachment to balls."})
 return base

def reference(task):
 def a(p,t=1.5,**kw):return dict(pos=p,duration=t,**kw)
 if task=="tunnel_retrieval":return {"tool":[{"type":"box","pos":[.11,0,0],"size":[.11,.004,.006]},{"type":"box","pos":[.22,-.033,0],"size":[.006,.04,.012]}],"actions":[a([.30,.10,.20]),a([.30,.10,.066]),a([.50,.10,.066],2),a([.50,.025,.066]),a([.30,.025,.066],3)],"reasoning":"Thin L hook enters beside block, shifts behind it, and pulls outward."}
 if task=="plate_lifting":return {"tool":[{"type":"box","pos":[.075,0,-.017],"size":[.075,.035,.002]},{"type":"box","pos":[0,0,-.008],"size":[.008,.035,.01]}],"actions":[a([.30,0,.2]),a([.30,0,.061]),a([.45,0,.061],3),a([.45,0,.20],3),a([.45,0,.20],1)],"reasoning":"Thin spatula slides through the under-plate gap and lifts."}
 if task=="ball_transfer":
  # Horizontal scoop base below ball centers; front lip lower than source wall to scoop over by tipping.
  tool=[{"type":"box","pos":[.02,0,-.01],"size":[.02,.012,.025]},{"type":"box","pos":[.13,0,-.04],"size":[.09,.075,.002]},{"type":"box","pos":[.04,0,-.01],"size":[.004,.075,.03]}]
  for y in [-.075,.075]:tool.append({"type":"box","pos":[.13,y,-.01],"size":[.09,.003,.03]})
  q=[.965925826,0,-.258819045,0]
  return {"tool":tool,"actions":[a([.28,-.17,.22]),a([.28,-.17,.097]),a([.44,-.17,.097],3),a([.44,-.17,.10],3,quat=q),a([.44,-.17,.28],3,quat=q),a([.44,.19,.28],4,quat=q),a([.44,.19,.21],2,quat=q),a([.44,.19,.21],3,quat=[.8660254,0,.5,0]),a([.44,.19,.21],2,quat=[.7071068,0,.7071068,0])],"reasoning":"Scoop under balls across the shallow front lip; tilt backward to retain, carry above receiver, and tip forward."}
