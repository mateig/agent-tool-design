"""Read-only structural/provenance audit of the complete frozen 54-search dataset.

Uses only the Python standard library. No simulation, API calls, filtering, repairs,
or result rewriting. An existing sensitivity directory must contain all 2160 records.
"""
import argparse
import ast
from copy import deepcopy
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
SOURCES = {"sim.py", "tasks_a.py", "tasks_b.py", "api.py",
           "experiment.py", "sensitivity.py"}
RECORD_SOURCES = SOURCES - {"sensitivity.py"}
CONDITIONS = {"invented_tool", "first_candidate", "tool_removed", "generic_rod"}
INFRA_MARKERS = ("TimeoutError", "BrokenProcessPool", "BrokenThreadPool",
                 "CancelledError")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def rank(rows):
    return (
        sum(bool(row.get("success")) for row in rows),
        sum(not bool(row.get("violations")) for row in rows),
        sum(float(row.get("score", 0)) if not row.get("violations") else 0
            for row in rows) / max(1, len(rows)),
    )


def audit_dataset(root, tag, require_sensitivity=False):
    root = Path(root).resolve()
    base = root / "results" / tag
    errors = []
    checks = 0
    stats = {"searches": 0, "candidates": 0, "heldout_records": 0,
             "control_records": 0, "sensitivity_records": 0,
             "release_collision_audit_records": 0, "ball_support_audit_records": 0,
             "legitimate_output_failures": 0,
             "training_seed_inferred_from_frozen_position": 0,
             "unchanged_files_byte_verified": 0}

    def check(condition, message):
        nonlocal checks
        checks += 1
        if not condition:
            errors.append(message)
        return bool(condition)

    def read(path):
        try:
            return json.loads(path.read_text())
        except (OSError, ValueError) as error:
            try:
                label = str(path.relative_to(root))
            except ValueError:
                label = str(path)
            errors.append(label + ": " + str(error))
            return None

    protocol = read(root / "protocol/frozen_protocol.json")
    if not protocol:
        return {"ok": False, "errors": errors, "stats": stats}
    hashes = protocol.get("source_sha256", {})
    check(set(hashes) == SOURCES, "Protocol must freeze all six source files")
    for name, digest in hashes.items():
        path = root / name
        check(path.is_file() and sha(path) == digest,
              "Frozen source drift or missing source: " + name)
    expected_fingerprint = {name: hashes.get(name) for name in RECORD_SOURCES}
    models = set(protocol["models"])
    tasks = set(protocol["tasks"])
    train = protocol["train_seeds"]
    seeds = protocol["heldout_seeds"]
    runs = protocol["design_runs"]
    budget = protocol["candidate_budget"]
    check(len(models) == 3 and len(tasks) == 6 and runs == 3 and budget == 4,
          "Expected frozen 3-model/6-task/3-run/4-candidate design")
    check(train == [0, 1, 2] and seeds == list(range(100, 110)),
          "Unexpected train or heldout seeds")
    expected = {(model, task, run)
                for model in models for task in tasks for run in range(runs)}
    expected_rows = {(*key, condition, seed)
                     for key in expected for condition in CONDITIONS for seed in seeds}
    system = None
    try:
        tree = ast.parse((root / "experiment.py").read_text())
        for node in tree.body:
            if (isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == "SYSTEM"
                            for target in node.targets)):
                system = ast.literal_eval(node.value)
    except (OSError, ValueError, SyntaxError) as error:
        errors.append("Cannot read frozen SYSTEM prompt: " + str(error))
    check(isinstance(system, str), "Frozen SYSTEM prompt was not found")

    def fingerprint(record, label):
        check(record.get("fingerprint") == expected_fingerprint,
              label + ": five-source record fingerprint mismatch")

    def residual(record, label):
        message = record.get("parse_error", "")
        check(not any(marker in message for marker in INFRA_MARKERS),
              label + ": residual infrastructure failure " + message[:150])
        check("render_error" not in record,
              label + ": residual feedback-render infrastructure failure")

    def row_check(row, label):
        if not check(isinstance(row, dict), label + ": result is not an object"):
            return
        check(isinstance(row.get("success"), bool), label + ": success must be boolean")
        score = row.get("score", 0)
        check(isinstance(score, (int, float)) and math.isfinite(score),
              label + ": nonfinite/non-numeric score")
        violations = row.get("violations", [])
        check(isinstance(violations, list), label + ": violations must be a list")
        check(not row.get("success") or not violations,
              label + ": success contradicts violations")
        text = json.dumps({"violations": violations,
                           "error": row.get("error", ""),
                           "traceback": row.get("traceback", "")})
        check(not any(marker in text for marker in INFRA_MARKERS),
              label + ": infrastructure exception in result")
        physics = row.get("physics", {})
        if row.get("success"):
            check(not any(physics.get("warning_counts", {}).values()),
                  label + ": success has numerical warnings")
            penetration = physics.get("max_all_contact_penetration")
            check(isinstance(penetration, (int, float))
                  and math.isfinite(penetration) and penetration <= .01,
                  label + ": success fails frozen 10mm contact gate")
            dt = physics.get("timestep", .002)
            mismatch = physics.get("time_mismatch", math.inf)
            check(isinstance(mismatch, (int, float)) and mismatch <= dt * 1.05,
                  label + ": success has simulation reset/time mismatch")

    config = read(base / "config.json")
    if config:
        fingerprint(config, "config")
        check(config.get("runs") == runs and config.get("candidates") == budget
              and config.get("max_tokens") == protocol["max_output_tokens_per_candidate"],
              "Dataset configuration differs from frozen interface budgets")
        check(config.get("train_seeds") == train and config.get("heldout_seeds") == seeds,
              "Dataset configuration seed lists differ")
        if "models" in config:
            check(set(config["models"]) == models, "Dataset model list differs")
        if "tasks" in config:
            check(set(config["tasks"]) == tasks, "Dataset task list differs")

    selections = {}
    seen_candidates = set()
    for model, task, run in sorted(expected):
        folder = base / "search" / model / task / f"run_{run}"
        records = []
        for attempt in range(budget):
            path = folder / f"candidate_{attempt}.json"
            record = read(path)
            if record is None:
                continue
            label = f"{model}/{task}/{run}/candidate_{attempt}"
            stats["candidates"] += 1
            seen_candidates.add((model, task, run, attempt))
            check((record.get("model"), record.get("task"), record.get("run"),
                   record.get("attempt")) == (model, task, run, attempt),
                  label + ": identity mismatch")
            fingerprint(record, label)
            check(record.get("system") == system, label + ": SYSTEM prompt drift")
            residual(record, label)
            check("api" in record or "parse_error" in record,
                  label + ": neither API response nor recorded failed attempt")
            if "parse_error" in record and not any(
                    marker in record["parse_error"] for marker in INFRA_MARKERS):
                stats["legitimate_output_failures"] += 1
                check(not any(row.get("success") for row in record.get("train_results", [])),
                      label + ": output failure has training success")
            api = record.get("api", {})
            if api.get("requested_model"):
                check(api["requested_model"] == protocol["models"][model],
                      label + ": requested API alias differs")
            rows = record.get("train_results", [])
            check(len(rows) == len(train), label + ": must have three training results")
            for position, row in enumerate(rows):
                row_check(row, label + f"/train_{position}")
                if position >= len(train):
                    continue
                if "seed" in row:
                    check(row["seed"] == train[position],
                          label + ": training seeds must be ordered 0,1,2")
                else:
                    # Frozen sim early rejection and frozen search output-failure rows
                    # omit seed; their order is fixed by TRAIN and is not imputed data.
                    stats["training_seed_inferred_from_frozen_position"] += 1
                    check(not row.get("success") and bool(row.get("violations")),
                          label + ": a successful/non-rejected training row lacks seed")
            records.append(record)

        candidate_paths = set(folder.glob("candidate_[0-9].json"))
        check(len(candidate_paths) == budget,
              f"{model}/{task}/{run}: expected exactly four candidate record files")
        selection = read(folder / "selected.json")
        if selection is None:
            continue
        stats["searches"] += 1
        selections[(model, task, run)] = selection
        label = f"{model}/{task}/{run}/selection"
        check((selection.get("model"), selection.get("task"), selection.get("run"))
              == (model, task, run), label + ": identity mismatch")
        fingerprint(selection, label)
        check(selection.get("candidate_count") == budget, label + ": candidate count differs")
        if len(records) == budget:
            try:
                # max preserves the earlier candidate on an exact rank tie.
                best = max(records, key=lambda record: rank(record.get("train_results", [])))
                expected_rank = rank(best.get("train_results", []))
                check(selection.get("selected_attempt") == best["attempt"],
                      label + ": not deterministic lexicographic/earliest-tie selection")
                actual_rank = selection.get("train_rank", [])
                check(len(actual_rank) == 3
                      and all(math.isclose(float(a), float(b), rel_tol=1e-12, abs_tol=1e-12)
                              for a, b in zip(actual_rank, expected_rank)),
                      label + ": stored training rank mismatch")
                check(selection.get("proposal") == best.get(
                    "proposal", {"tool": [], "actions": []}),
                    label + ": selected proposal differs from selected candidate")
            except (ValueError, TypeError, KeyError) as error:
                errors.append(label + ": ranking audit failed: " + str(error))

    check(len(list((base / "search").glob("*/*/run_*/selected.json"))) == 54,
          "Expected exactly 54 selection files")
    check(len(list((base / "search").glob("*/*/run_*/candidate_[0-9].json"))) == 216,
          "Expected exactly 216 candidate files")
    heldout = {}
    for model, task, run in sorted(expected):
        label = f"{model}/{task}/{run}/heldout"
        record = read(base / "heldout" / model / task / f"run_{run}.json")
        if record is None:
            continue
        fingerprint(record, label)
        check(record.get("selection") == selections.get((model, task, run)),
              label + ": selected design/provenance mismatch")
        check(record.get("heldout_seeds") == seeds, label + ": heldout seed list mismatch")
        rows = record.get("rows", [])
        check(len(rows) == 40, label + ": expected four conditions x ten seeds")
        local = set()
        for row in rows:
            row_check(row, label)
            key = (model, task, run, row.get("condition"), row.get("seed"))
            check(key in expected_rows, label + ": unknown condition or heldout seed")
            check(key not in local and key not in heldout,
                  label + ": duplicate condition/seed")
            local.add(key)
            heldout[key] = row
            stats["heldout_records"] += 1
        check({(key[3], key[4]) for key in local}
              == {(condition, seed) for condition in CONDITIONS for seed in seeds},
              label + ": incomplete distinct condition/seed grid")
    check(set(heldout) == expected_rows, "Heldout rows do not cover all 2160 expected keys")
    check(len(list((base / "heldout").glob("*/*/run_*.json"))) == 54,
          "Expected exactly 54 heldout files")

    controls = read(base / "controls.json")
    if controls:
        fingerprint(controls, "controls")
        keys = []
        for row in controls.get("rows", []):
            row_check(row, "controls")
            keys.append((row.get("task"), row.get("condition"), row.get("seed")))
        expected_controls = {(task, condition, seed) for task in tasks
                             for condition in ["reference", "idle"] for seed in seeds}
        check(len(keys) == 120 and len(set(keys)) == 120 and set(keys) == expected_controls,
              "Controls must contain all 120 distinct reference/idle replay keys")
        stats["control_records"] = len(keys)

    # Recovery is outcome-independent and must preserve unaffected source bytes.
    if config and config.get("recovery_registry"):
        raw_registry = Path(config["recovery_registry"])
        packaged_registry = root / "protocol" / raw_registry.name
        registry_path = packaged_registry if packaged_registry.is_file() else raw_registry
        registry = read(registry_path)
        if registry:
            check(registry.get("final_dataset") == tag, "Recovery registry final tag mismatch")
            source = root / "results" / registry["source_dataset"]
            unchanged = {(r["model"], r["task"], r["run"])
                         for r in registry.get("unchanged", [])}
            replaced = {(r["model"], r["task"], r["run"])
                        for r in registry.get("replacements", [])}
            check(not unchanged & replaced and unchanged | replaced == expected,
                  "Recovery registry must partition exactly the 54 searches")
            check(len(unchanged) == len(registry.get("unchanged", []))
                  and len(replaced) == len(registry.get("replacements", [])),
                  "Duplicate search entries in recovery registry")
            for model, task, run in sorted(unchanged):
                original = source / "search" / model / task / f"run_{run}"
                final = base / "search" / model / task / f"run_{run}"
                for filename in [*[f"candidate_{attempt}.json" for attempt in range(budget)], "selected.json"]:
                    check((original / filename).is_file(),
                          "Missing required unchanged original record: " + str(original / filename))
                original_files = [p for p in original.rglob("*") if p.is_file()]
                check(bool(original_files), "Missing unchanged original search: " + str(original))
                for path in original_files:
                    copy = final / path.relative_to(original)
                    if check(copy.is_file() and sha(copy) == sha(path),
                             "Unchanged search file differs: "
                             + str(copy.relative_to(root))):
                        stats["unchanged_files_byte_verified"] += 1
            for record in registry.get("replacements", []):
                model, task, run = record["model"], record["task"], record["run"]
                original = source / "search" / model / task / f"run_{run}"
                old_selection = read(original / "selected.json")
                check(old_selection == record.get("original_selection"),
                      "Registry original selection changed")
                check(bool(record.get("reasons")), "Replacement lacks prespecified reason")
                for reason in record.get("reasons", []):
                    path = original / f"candidate_{reason['candidate']}.json"
                    check(path.is_file() and sha(path) == reason["original_sha256"],
                          "Quarantined original candidate changed")
                old_ids = set()
                for path in original.glob("candidate_[0-9].json"):
                    old_record = read(path)
                    if old_record and old_record.get("api", {}).get("id"):
                        old_ids.add(old_record["api"]["id"])
                for attempt in range(budget):
                    path = (base / "search" / model / task / f"run_{run}"
                            / f"candidate_{attempt}.json")
                    new_record = read(path)
                    if new_record:
                        check(new_record.get("created_utc", "")
                              >= registry.get("created_before_replacements_utc", ""),
                              "Replacement candidate predates frozen recovery registry")
                        new_id = new_record.get("api", {}).get("id")
                        check(not new_id or new_id not in old_ids,
                              "Replacement reused original API response ID")

    sensitivity = base / "sensitivity"
    if sensitivity.is_dir() or require_sensitivity:
        strict_keys = set()
        files = [p for p in sensitivity.glob("*.json") if p.name != "summary.json"]
        check(len(files) == 2160, "Sensitivity must contain exactly 2160 per-replay JSON files")
        for path in files:
            record = read(path)
            if record is None:
                continue
            key = (record.get("model"), record.get("task"), record.get("run"),
                   record.get("condition"), record.get("seed"))
            check(key in expected_rows and key not in strict_keys,
                  "Unknown or duplicate sensitivity key: " + path.name)
            strict_keys.add(key)
            stats["sensitivity_records"] += 1
            main = heldout.get(key, {})
            check(record.get("main_success") == bool(main.get("success")),
                  path.name + ": main success metadata mismatch")
            check(isinstance(record.get("strict_success"), bool),
                  path.name + ": strict success must be boolean")
            check("error" not in record, path.name + ": sensitivity worker error")
            if not main.get("success"):
                check(record.get("strict_success") is False and record.get("rerun") is False,
                      path.name + ": main failure incorrectly enters joint success")
            else:
                check(record.get("rerun") is True and isinstance(record.get("result"), dict),
                      path.name + ": main success missing required 1ms replay")
                result = record.get("result", {})
                row_check(result, path.name + "/1ms")
                physics = result.get("physics", {})
                check(physics.get("timestep") == .001,
                      path.name + ": sensitivity timestep differs from 1ms")
                pen = physics.get("max_all_contact_penetration", math.inf)
                expected_strict = bool(result.get("success")) and pen <= .005
                check(record.get("strict_success") == expected_strict,
                      path.name + ": strict criterion mismatch")
        check(strict_keys == expected_rows, "Sensitivity does not cover all 2160 replay keys")

    collision = base / "release_collision_audit"
    if collision.is_dir():
        expected_collision = {(model, run, condition, seed, dt)
                              for model in models for run in range(runs)
                              for condition in CONDITIONS for seed in seeds
                              for dt in [.002, .001]}
        collision_keys = set()
        files = [p for p in collision.glob("*.json")
                 if p.name != "summary.json" and not p.name.startswith("reference_")]
        check(len(files) == 720,
              "Release collision audit must contain exactly 720 per-replay JSON files")
        for path in files:
            record = read(path)
            if record is None:
                continue
            key = (record.get("model"), record.get("run"), record.get("condition"),
                   record.get("seed"), record.get("timestep"))
            check(key in expected_collision and key not in collision_keys,
                  "Unknown or duplicate release-collision key: " + path.name)
            collision_keys.add(key)
            stats["release_collision_audit_records"] += 1
            main_key = (key[0], "door_prop", key[1], key[2], key[3])
            main = heldout.get(main_key, {})
            check(record.get("main_success") == bool(main.get("success")),
                  path.name + ": collision audit main-success metadata mismatch")
            check("error" not in record, path.name + ": collision audit worker error")
            check(isinstance(record.get("corrected_success"), bool)
                  and isinstance(record.get("strict_corrected_success"), bool),
                  path.name + ": collision-audit outcomes must be boolean")
            if not main.get("success"):
                check(record.get("rerun") is False
                      and record.get("corrected_success") is False
                      and record.get("strict_corrected_success") is False,
                      path.name + ": main failure incorrectly enters corrected success")
                continue
            check(record.get("rerun") is True and isinstance(record.get("result"), dict),
                  path.name + ": main door success missing required corrected replay")
            result = record.get("result", {})
            row_check(result, path.name + "/corrected")
            physics = result.get("physics", {})
            check(physics.get("timestep") == key[4],
                  path.name + ": corrected timestep mismatch")
            check(record.get("corrected_success") == bool(result.get("success")),
                  path.name + ": corrected success does not match evaluator")
            release = result.get("release_collision_audit", {})
            crossings = release.get("entrance_crossings", [])
            for crossing in crossings:
                causal = bool(crossing.get("within_full_aperture")
                              and crossing.get("tool_door_contact")
                              and crossing.get("gripper_block_contact")
                              and crossing.get("door_angle", 0) > .65)
                check(crossing.get("valid") == causal,
                      path.name + ": causal doorway-crossing conjunction mismatch")
            valid_crossing = any(bool(crossing.get("valid")) for crossing in crossings)
            check(result.get("geometric_causal_crossing_valid") == valid_crossing,
                  path.name + ": geometric crossing result mismatch")
            if result.get("success"):
                check(release.get("restored") is True
                      and release.get("restored_exclusions") == 3,
                      path.name + ": successful door replay did not restore all exclusions")
            pen = physics.get("max_all_contact_penetration", math.inf)
            strict = bool(result.get("success")) and valid_crossing and pen <= .005
            check(record.get("strict_corrected_success") == strict
                  and result.get("strict_corrected_success") == strict,
                  path.name + ": strict corrected conjunction mismatch")
        check(collision_keys == expected_collision,
              "Release collision audit does not cover all 720 replay keys")

    ball_dir = base / "ball_support_audit"
    if ball_dir.is_dir():
        expected_ball = {(model, "ball_transfer", run, condition, seed)
                         for model in models for run in range(runs)
                         for condition in CONDITIONS for seed in seeds}
        files = [p for p in ball_dir.glob("*.json") if p.name != "summary.json"]
        check(len(files) == 360, "Ball support audit must contain exactly 360 replay JSON files")
        ball_keys = set()
        observer_path = root / "ball_support_audit.py"
        observer_sha = sha(observer_path) if observer_path.is_file() else None
        check(observer_sha is not None, "Missing ball-support audit source")
        for path in files:
            record = read(path)
            if record is None:
                continue
            key = (record.get("model"), record.get("task"), record.get("run"),
                   record.get("condition"), record.get("seed"))
            check(key in expected_ball and key not in ball_keys,
                  "Unknown or duplicate ball-support key: " + path.name)
            ball_keys.add(key)
            stats["ball_support_audit_records"] += 1
            main = heldout.get(key, {})
            check(record.get("main_success") == bool(main.get("success")),
                  path.name + ": ball-support main-result flag mismatch")
            check(record.get("timestep") == .001
                  and record.get("audit_version") == "ball_support_v1",
                  path.name + ": ball-support version/timestep mismatch")
            check(record.get("audit_sha256") == observer_sha,
                  path.name + ": ball-support observer source hash mismatch")
            check("error" not in record, path.name + ": ball-support worker error")
            check(isinstance(record.get("deposit_retained"), bool),
                  path.name + ": deposit_retained must be boolean")
            source_path = (base / "heldout" / str(key[0]) / "ball_transfer"
                           / f"run_{key[2]}.json")
            check(source_path.is_file()
                  and record.get("source_heldout_sha256") == sha(source_path),
                  path.name + ": source heldout checksum mismatch")
            selection = selections.get(key[:3], {})
            proposal = deepcopy(selection.get("proposal", {"tool": [], "actions": []}))
            if key[3] == "first_candidate":
                first_path = (base / "search" / str(key[0]) / "ball_transfer"
                              / f"run_{key[2]}" / "candidate_0.json")
                first = read(first_path)
                proposal = first.get("proposal", {"tool": [], "actions": []}) if first else {}
            elif key[3] == "tool_removed":
                proposal["tool"] = []
            elif key[3] == "generic_rod":
                proposal["tool"] = [{"type": "box", "pos": [0, 0, -.10],
                                     "size": [.008, .008, .10]}]
            proposal_sha = hashlib.sha256(json.dumps(proposal, sort_keys=True).encode()).hexdigest()
            check(record.get("proposal_sha256") == proposal_sha,
                  path.name + ": ball audit did not use the recorded condition proposal")
            if not main.get("success"):
                check(record.get("rerun") is False and record.get("deposit_retained") is False,
                      path.name + ": main failure incorrectly retained as a deposit")
                continue
            check(record.get("rerun") is True and isinstance(record.get("result"), dict),
                  path.name + ": positive main ball replay missing 1ms audit")
            result = record.get("result", {})
            row_check(result, path.name + "/ball_1ms")
            physics = result.get("physics", {})
            check(physics.get("timestep") == .001,
                  path.name + ": ball audit core timestep mismatch")
            observation = result.get("ball_support_audit", {})
            predicate = observation.get("predicate", {})
            check(predicate.get("timestep") == .001
                  and predicate.get("window_seconds") == 1.
                  and predicate.get("containment_tolerance_m_on_all_six_boundaries") == .001
                  and predicate.get("maximum_linear_speed_m_s") == .04
                  and predicate.get("maximum_ball_tool_contact_steps") == 0
                  and predicate.get("maximum_ball_robot_contact_steps") == 0
                  and predicate.get("maximum_all_contact_penetration_m") == .005,
                  path.name + ": declared posthoc deposit predicate mismatch")
            samples = observation.get("samples", -1)
            complete = (samples == 1000 and observation.get("required_samples") == 1000
                        and observation.get("observed_step_calls")
                        == observation.get("expected_action_step_calls", -2000)+1000)
            check(observation.get("complete_final_settling_window") == complete,
                  path.name + ": incomplete or inconsistent final 1000-step window")
            inside = complete and observation.get("containment_failure_steps") == 0
            slow = complete and observation.get("speed_failure_steps") == 0
            no_tool = complete and observation.get("tool_contact_steps") == 0
            no_robot = complete and observation.get("robot_contact_steps") == 0
            check(observation.get("all_three_inside_every_step") == inside
                  and observation.get("all_three_settled_every_step") == slow
                  and observation.get("no_ball_tool_contact_every_step") == no_tool
                  and observation.get("no_ball_robot_contact_every_step") == no_robot,
                  path.name + ": final-step deposit aggregate mismatch")
            if inside and slow:
                check(observation.get("nonfinite_steps") == 0,
                      path.name + ": accepted deposit has nonfinite states")
                max_speed = observation.get("max_linear_speed", math.inf)
                excess = observation.get("max_containment_boundary_excess_m", math.inf)
                check(isinstance(max_speed, (int, float)) and max_speed <= .04
                      and isinstance(excess, (int, float)) and excess <= .001+1e-12,
                      path.name + ": deposit aggregate exceeds speed/containment limit")
            core = (bool(result.get("success"))
                    and physics.get("max_all_contact_penetration", math.inf) <= .005)
            retained = bool(core and inside and slow and no_tool and no_robot)
            check(record.get("deposit_retained") == retained
                  and result.get("deposit_retained") == retained,
                  path.name + ": exact conservative deposit conjunction mismatch")
        check(ball_keys == expected_ball, "Ball support audit does not cover all 360 replay keys")

    return {
        "ok": not errors, "dataset": tag, "checks": checks,
        "stats": stats, "error_count": len(errors), "errors": errors[:100],
        "errors_truncated": max(0, len(errors) - 100),
        "frozen_source_sha256": hashes,
        "notes": [
            "Candidate output-budget exhaustion, empty/no-JSON output, and invalid schemas "
            "remain counted attempts; they are not removed for low performance.",
            "Seed-less rejected/synthetic training rows use the frozen positional TRAIN "
            "ordering [0,1,2]; no simulated result or success is imputed.",
            "This audits provenance and record consistency, not scientific merit or "
            "physical validity beyond recorded diagnostics.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tag", default="main_v1_final")
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--require-sensitivity", action="store_true")
    parser.add_argument("--output", type=Path,
                        help="Optional new audit report; trial records are never changed.")
    args = parser.parse_args()
    if not args.tag or Path(args.tag).name != args.tag or args.tag in {".", ".."}:
        parser.error("--tag must be a simple results directory name")
    report = audit_dataset(args.root, args.tag, args.require_sensitivity)
    text = json.dumps(report, indent=2, allow_nan=False)
    if args.output:
        if args.output.exists():
            parser.error("--output already exists; choose a new audit-report path")
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text + "\n")
    print(text)
    raise SystemExit(0 if report["ok"] else 1)


if __name__ == "__main__":
    main()
