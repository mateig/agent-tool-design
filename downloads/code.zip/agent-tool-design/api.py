"""API adapter. Secrets are read outside the repository and never serialized."""
import json, time, pathlib, re, traceback, os
from concurrent.futures import ThreadPoolExecutor
KEYS=pathlib.Path("/root/.config/corl/keys.json")
MODELS={"astra":"gpt-6-astra","sol":"gpt-6.1-sol","opus":"claude-opus-5-5"}
def credentials():
    keys=json.loads(KEYS.read_text()) if KEYS.exists() else {}
    for name,env in [("openai","OPENAI_API_KEY"),("anthropic","ANTHROPIC_API_KEY"),("anthropic_workspace","ANTHROPIC_WORKSPACE_ID")]:
        if os.environ.get(env):keys[name]=os.environ[env]
    return keys
def call(model,system,user,images=None,max_tokens=16000,effort="high"):
    import base64
    keys=credentials(); start=time.monotonic()
    if model in ("astra","sol"):
        from openai import OpenAI
        client=OpenAI(api_key=keys["openai"],timeout=600,max_retries=2)
        content=[{"type":"input_text","text":user}]
        for im in images or []:
            content.append({"type":"input_image","image_url":"data:image/png;base64,"+base64.b64encode(pathlib.Path(im).read_bytes()).decode(),"detail":"high"})
        r=client.responses.create(model=MODELS[model],instructions=system,input=[{"role":"user","content":content}],reasoning={"effort":effort},max_output_tokens=max_tokens,store=False)
        return {"text":r.output_text,"id":r.id,"requested_model":MODELS[model],"returned_model":r.model,"usage":r.usage.model_dump() if r.usage else {},"seconds":time.monotonic()-start,"status":r.status}
    from anthropic import Anthropic
    client=Anthropic(api_key=keys["anthropic"],timeout=600,max_retries=2,default_headers=({"anthropic-workspace-id":keys["anthropic_workspace"]} if keys.get("anthropic_workspace") else {}))
    content=[]
    for im in images or []:
        content.append({"type":"image","source":{"type":"base64","media_type":"image/png","data":base64.b64encode(pathlib.Path(im).read_bytes()).decode()}})
    content.append({"type":"text","text":user})
    r=client.messages.create(model=MODELS[model],system=system,messages=[{"role":"user","content":content}],max_tokens=max_tokens,thinking={"type":"adaptive"},output_config={"effort":effort})
    return {"text":"\n".join(b.text for b in r.content if getattr(b,"type","")=="text"),"id":r.id,"requested_model":MODELS[model],"returned_model":r.model,"usage":r.usage.model_dump(),"seconds":time.monotonic()-start,"status":r.stop_reason}
def extract_json(text):
    text=text.strip()
    if text.startswith("\x60\x60\x60"):
        text=re.sub(r"^\x60\x60\x60(?:json)?\s*|\s*\x60\x60\x60$","",text,flags=re.S)
    dec=json.JSONDecoder()
    for i,c in enumerate(text):
        if c=="{":
            try:
                obj,end=dec.raw_decode(text[i:])
                if isinstance(obj,dict): return obj
            except json.JSONDecodeError: pass
    raise ValueError("Response contains no valid JSON object")
if __name__=="__main__":
    def test(m):
        try:
            r=call(m,"Respond to the request briefly.","Return the JSON object {\"ok\":true} only.",max_tokens=1024,effort="low")
            pathlib.Path("logs").mkdir(exist_ok=True)
            pathlib.Path("logs/api_probe_"+m+".json").write_text(json.dumps(r,indent=2))
            print(m, r["returned_model"],r["status"],r["text"][:200],flush=True)
        except Exception as e:
            print(m,type(e).__name__,str(e)[:1000],flush=True)
    with ThreadPoolExecutor(max_workers=3) as ex: list(ex.map(test,MODELS))

