"""Conservative retained-outcome view: planned numerical check + explicit posthoc door audit."""
import pathlib,json,collections,statistics,argparse,csv
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
TASKS=["tunnel_retrieval","plate_lifting","ball_transfer","recessed_knob","two_buttons","door_prop"]
NAMES=["Tunnel","Plate","Balls","Knob","Buttons","Door"]
MODELS={"astra":"Astra 6","sol":"Sol 6.1","opus":"Opus 5.5"}
CONDS=["invented_tool","first_candidate","tool_removed","generic_rod"]
def main():
 ap=argparse.ArgumentParser();ap.add_argument("--tag",default="main_v1_final");a=ap.parse_args()
 base=ROOT/"results"/a.tag
 held=[json.loads(p.read_text()) for p in base.glob("heldout/*/*/run_*.json")]
 strict={}
 for p in (base/"sensitivity").glob("*.json"):
  if p.name=="summary.json":continue
  r=json.loads(p.read_text());strict[(r["model"],r["task"],r["run"],r["condition"],r["seed"])]=r
 coll={}
 for p in (base/"release_collision_audit").glob("*.json"):
  if p.name=="summary.json" or p.name.startswith("reference_"):continue
  r=json.loads(p.read_text());coll[(r["model"],r["run"],r["condition"],r["seed"],r["timestep"])]=r
 ball={}
 for p in (base/"ball_support_audit").glob("*.json"):
  if p.name=="summary.json":continue
  r=json.loads(p.read_text());ball[(r["model"],r["run"],r["condition"],r["seed"])]=r
 assert len(ball)==360,"Require complete posthoc ball support audit"
 assert len(held)==54 and len(strict)==2160,"Require complete main and planned sensitivity"
 assert len(coll)==720,"Require all door condition/seed audit entries at both timesteps"
 rows=[]
 for h in held:
  sel=h["selection"];m,t,run=sel["model"],sel["task"],sel["run"]
  for r in h["rows"]:
   c,seed=r["condition"],r["seed"];ss=strict[(m,t,run,c,seed)]
   assert bool(ss["main_success"])==bool(r["success"])
   planned=bool(ss["strict_success"]);retained=planned;doorpass=None;ballpass=None
   if t=="door_prop":
    c2=coll[(m,run,c,seed,.002)];c1=coll[(m,run,c,seed,.001)]
    doorpass=bool(c2.get("corrected_success")) and bool(c2.get("result",{}).get("geometric_causal_crossing_valid")) and bool(c1.get("strict_corrected_success"))
    retained=planned and doorpass
   if t=="ball_transfer":
    ba=ball[(m,run,c,seed)]
    assert bool(ba["main_success"])==bool(r["success"])
    ballpass=bool(ba["deposit_retained"])
    retained=retained and ballpass
   rows.append({"model":m,"task":t,"run":run,"condition":c,"seed":seed,"main_success":bool(r["success"]),"planned_sensitivity_retained":planned,"posthoc_door_audit_retained":doorpass,"posthoc_ball_deposit_audit_retained":ballpass,"retained":retained})
 summary={"tag":a.tag,"rows":len(rows),"definition":"Retained = original main pass AND predeclared1ms/<=5mm pass; door additionally requires posthoc collision-restored2ms pass with valid geometric causal crossing and collision-restored1ms<=5mm pass. Ball additionally requires the posthoc1ms final-settle unassisted-deposit check. Conservative conjunction, not full corrected-benchmark performance.","models":{}}
 for m,label in MODELS.items():
  ms={"label":label,"by_task":{},"conditions":{}}
  for t in TASKS:
   ms["by_task"][t]={}
   for c in CONDS:
    rr=[r for r in rows if r["model"]==m and r["task"]==t and r["condition"]==c]
    per=[sum(r["retained"] for r in rr if r["run"]==run)/10 for run in range(3)]
    ms["by_task"][t][c]={"n":len(rr),"main_successes":sum(r["main_success"] for r in rr),"planned_sensitivity_successes":sum(r["planned_sensitivity_retained"] for r in rr),"retained_successes":sum(r["retained"] for r in rr),"rate":sum(r["retained"] for r in rr)/len(rr),"per_run_rates":per,"sd_across_searches":statistics.stdev(per)}
  for c in CONDS:
   rr=[r for r in rows if r["model"]==m and r["condition"]==c]
   ms["conditions"][c]={"n":len(rr),"main_successes":sum(r["main_success"] for r in rr),"planned_sensitivity_successes":sum(r["planned_sensitivity_retained"] for r in rr),"retained_successes":sum(r["retained"] for r in rr),"rate":sum(r["retained"] for r in rr)/len(rr)}
  rng=np.random.default_rng(92031);arrs=[ms["by_task"][t]["invented_tool"]["per_run_rates"] for t in TASKS]
  boots=[float(np.mean([np.mean(rng.choice(x,3,replace=True)) for x in arrs])) for _ in range(10000)]
  ms["fixed_task_search_bootstrap95"]=np.percentile(boots,[2.5,97.5]).tolist()
  summary["models"][m]=ms
 summary["selected_main_successes"]=sum(r["main_success"] for r in rows if r["condition"]=="invented_tool")
 summary["selected_retained_successes"]=sum(r["retained"] for r in rows if r["condition"]=="invented_tool")
 summary["selected_planned_sensitivity_successes"]=sum(r["planned_sensitivity_retained"] for r in rows if r["condition"]=="invented_tool")
 summary["selected_replay_n"]=sum(r["condition"]=="invented_tool" for r in rows)
 summary["task_coverage_retained"]=sum(any(r["retained"] for r in rows if r["task"]==t and r["condition"]=="invented_tool") for t in TASKS)
 out=ROOT/"analysis";out.mkdir(exist_ok=True)
 (out/"validated_summary.json").write_text(json.dumps(summary,indent=2))
 with (out/"validated_trials.csv").open("w",newline="") as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 tex=[r"\begin{tabular}{lrrrrrrr}",r"\toprule",r"Model & Tunnel & Plate & Balls & Knob & Buttons & Door & Mean \\",r"\midrule"]
 md=["# Conservative retained outcomes","","Each cell shows retained [main-gate] successes, out of30.","","| Model | "+" | ".join(NAMES)+" | Macro |","|---|"+"---|"*7]
 for m,ms in summary["models"].items():
  cells=[f"{ms['by_task'][t]['invented_tool']['retained_successes']} [{ms['by_task'][t]['invented_tool']['main_successes']}]" for t in TASKS]
  co=ms["conditions"]["invented_tool"];rate=f"{co['rate']*100:.1f}"
  tex.append(ms["label"]+" & "+" & ".join(cells)+" & "+rate+r"\% \\")
  md.append("| "+ms["label"]+" | "+" | ".join(cells)+" | "+rate+"% |")
 tex += [r"\bottomrule",r"\end{tabular}"]
 (out/"validated_table.tex").write_text("\n".join(tex)+"\n");(out/"validated_summary.md").write_text("\n".join(md)+"\n")
 import matplotlib;matplotlib.use("Agg")
 import matplotlib.pyplot as plt
 plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False,"savefig.bbox":"tight"})
 fig,axs=plt.subplots(1,2,figsize=(7,2.25),gridspec_kw={"width_ratios":[1.5,1]})
 xx=np.arange(6);colors={"astra":"#3d679a","sol":"#419a85","opus":"#c47e3b"}
 for i,(m,ms) in enumerate(summary["models"].items()):
  raw=[ms["by_task"][t]["invented_tool"]["main_successes"]/30*100 for t in TASKS]
  vals=[ms["by_task"][t]["invented_tool"]["rate"]*100 for t in TASKS]
  axs[0].bar(xx+(i-1)*.23,raw,width=.22,facecolor="none",edgecolor=colors[m],linewidth=.8)
  axs[0].bar(xx+(i-1)*.23,vals,width=.17,label=ms["label"],color=colors[m])
  for j,t in enumerate(TASKS):
   pts=ms["by_task"][t]["invented_tool"]["per_run_rates"]
   axs[0].scatter(j+(i-1)*.23+np.linspace(-.035,.035,3),np.array(pts)*100,s=9,c="#172431",zorder=5,linewidths=.3,edgecolors="white")
 axs[0].set_xticks(xx,NAMES);axs[0].set_ylim(0,110);axs[0].set_ylabel("Retained success (%)");axs[0].legend(frameon=False,ncol=3,fontsize=7,loc="upper center",bbox_to_anchor=(.5,1.2))
 for m,ms in summary["models"].items():
  vals=[ms["conditions"][c]["rate"]*100 for c in CONDS]
  axs[1].plot(range(4),vals,"o-",color=colors[m],linewidth=1.4,markersize=4)
 axs[1].set_xticks(range(4),["Selected","First","Removed","Rod"],rotation=25)
 # CONDS ordered selected, first; use semantic order first, selected for the comparison panel.
 for line,m in zip(axs[1].lines,summary["models"]):
  line.set_ydata([summary["models"][m]["conditions"][c]["rate"]*100 for c in ["first_candidate","invented_tool","tool_removed","generic_rod"]])
 axs[1].set_xticks(range(4),["First","Selected","Removed","Rod"],rotation=25)
 axs[1].set_ylim(0,105);axs[1].set_ylabel("Retained macro success (%)")
 fig.tight_layout(w_pad=1.3);fig.savefig(out/"validated_plot.png",dpi=220);fig.savefig(out/"validated_plot.pdf");plt.close(fig)
 print(json.dumps({k:summary[k] for k in ["tag","selected_main_successes","selected_planned_sensitivity_successes","selected_retained_successes","selected_replay_n","task_coverage_retained"]},indent=2))
if __name__=="__main__":main()

