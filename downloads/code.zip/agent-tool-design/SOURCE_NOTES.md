# Source and license notes

The study code and task definitions were prepared for Matei Gardea, UC Berkeley EECS. The six experimental source files are identified by SHA-256 in `protocol/frozen_protocol.json`; `protocol/frozen_source/` retains their frozen copies. No project-wide license file has been assigned to the original study code in this package. Upstream licenses do not automatically license the study's original files.

The Franka Emika Panda MJCF, visual meshes, collision meshes, and robot inertial parameters come from Google DeepMind's MuJoCo Menagerie, commit `f3b6013629c7b94f8ee93fd977b161fa8350f9bc`:

https://github.com/google-deepmind/mujoco_menagerie/tree/f3b6013629c7b94f8ee93fd977b161fa8350f9bc/franka_emika_panda

The model's own README identifies its derivation from the public `franka_ros/franka_description` URDF and releases the model under Apache-2.0. Preserve `menagerie/franka_emika_panda/LICENSE`, its README, and other included attribution files with redistributed assets. The simulator reads that model and adds task fixtures and a generated tool in memory; it does not rewrite the upstream asset files.

Installed package versions are pinned in `requirements.txt` and summarized in `protocol/runtime_versions.json`. MuJoCo, NumPy, SciPy, Pillow, ImageIO, SDKs, and document tools retain their respective upstream licenses. The Python environment, API credentials, and private key files are not distribution assets.

`run_experiment.py` is a new scheduling wrapper around the frozen `experiment.search`, `experiment.heldout`, and `experiment.references` functions. It separates design search from heldout replay and ignores executor queue-wait timeouts. It changes no model prompt, alias, budget, selection rule, tool geometry, control, or success predicate. Its SHA-256 and the six frozen hashes are recorded in each new run's configuration.

`verify_dataset.py` is a read-only standard-library audit utility. It never calls a model, runs a simulation, rewrites data, repairs a result, or removes an unsuccessful attempt. It distinguishes recorded output/schema failures from infrastructure timeouts and requires any recovery to remain visible in the original records and registry.

The final study dataset is `results/main_v1_final/`. `results/main_v1/` is the original immutable audit source, including quarantined searches and incomplete/interleaved evaluation work. A fresh reproduction uses a new tag through `run_experiment.py`; it does not modify either dataset. API model aliases may resolve differently later, so future reproductions should report returned model identities and dates as well as requested aliases.
