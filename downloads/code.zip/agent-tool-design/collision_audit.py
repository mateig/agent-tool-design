"""Post-freeze diagnostic: restore tool-hand/finger contacts immediately upon tool release.
Never edits frozen sources, saved proposals, or original scored records.
Runtime exclusion lookup is confirmed in MuJoCo engine_collision_driver.c.
"""
import os
os.environ.setdefault("OPENBLAS_NUM_THREADS","1");os.environ.setdefault("OMP_NUM_THREADS","1");os.environ.setdefault("MUJOCO_GL","egl")
import pathlib,json,copy,argparse,concurrent.futures as cf,time,hashlib
ROOT=pathlib.Path(__file__).resolve().parent
def evaluate(task,design,seed=0,timestep=.002,video_path=None,trajectory_path=None):
 import mujoco,numpy as np,sim
 original=mujoco.mj_step
 state={"restored":False,"restored_exclusions":0,"restore_time":None,"postrelease_tool_hand_contacts":0,"max_postrelease_tool_hand_penetration":0.,"entrance_crossings":[]}
 def step(m,d,*args,**kw):
  wi=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_EQUALITY,"tool_weld")
  released=wi>=0 and not bool(d.eq_active[wi])
  if released and not state["restored"]:
   tool=m.body("tool").id;hands={m.body(n).id for n in ("hand","left_finger","right_finger")}
   target={(min(b,tool)<<16)+max(b,tool) for b in hands}
   idx=[i for i,s in enumerate(m.exclude_signature) if int(s) in target]
   for i in idx:m.exclude_signature[i]=np.iinfo(m.exclude_signature.dtype).max
   m.exclude_signature[:]=np.sort(m.exclude_signature)
   state.update(restored=True,restored_exclusions=len(idx),restore_time=float(d.time),tool_body=tool,hand_bodies=sorted(hands),removed_signatures=sorted(target))
  block=mujoco.mj_name2id(m,mujoco.mjtObj.mjOBJ_BODY,"door_block")
  before_x=float(d.xpos[block,0]) if block>=0 else None
  original(m,d,*args,**kw)
  if released and block>=0:
   door=m.body("spring_door").id;entrance=float(m.body_pos[door,0]);cy=float(m.body_pos[door,1]+.14)
   pos=d.xpos[block].copy()
   if before_x>=entrance and pos[0]<entrance:
    bg=m.geom("door_block_geom").id;R=d.geom_xmat[bg].reshape(3,3);extent=np.abs(R)@m.geom_size[bg,:3]
    door_geom=m.geom("door_panel").id;hands=set(state["hand_bodies"]);tool=state["tool_body"]
    tc=False;gc=False
    for c in d.contact:
     bs={int(m.geom_bodyid[c.geom1]),int(m.geom_bodyid[c.geom2])}
     if door_geom in (c.geom1,c.geom2) and tool in bs:tc=True
     if bg in (c.geom1,c.geom2) and bs.intersection(hands):gc=True
    angle=float(d.qpos[m.joint("door_hinge").qposadr[0]])
    within=bool(abs(pos[1]-cy)+extent[1]<=.16 and pos[2]+extent[2]<=.32 and pos[2]-extent[2]>=.04)
    state["entrance_crossings"].append({"time":float(d.time),"position":pos.tolist(),"projected_half_extent":extent.tolist(),"within_full_aperture":within,"tool_door_contact":tc,"gripper_block_contact":gc,"door_angle":angle,"valid":bool(within and tc and gc and angle>.65)})
  if released:
   tool=state["tool_body"];hands=set(state["hand_bodies"])
   for c in d.contact:
    b1,b2=int(m.geom_bodyid[c.geom1]),int(m.geom_bodyid[c.geom2])
    if (b1==tool and b2 in hands) or (b2==tool and b1 in hands):
     state["postrelease_tool_hand_contacts"]+=1
     state["max_postrelease_tool_hand_penetration"]=max(state["max_postrelease_tool_hand_penetration"],float(-c.dist))
 mujoco.mj_step=step
 try:r=sim.evaluate(task,design,seed=seed,timestep=timestep,video_path=video_path,trajectory_path=trajectory_path)
 finally:mujoco.mj_step=original
 r["release_collision_audit"]=state
 r["geometric_causal_crossing_valid"]=any(x["valid"] for x in state["entrance_crossings"])
 r["strict_corrected_success"]=bool(r.get("success")) and r["geometric_causal_crossing_valid"] and r.get("physics",{}).get("max_all_contact_penetration",float("inf"))<=.005
 return r
def dump(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(".tmp");tmp.write_text(json.dumps(x,indent=2));tmp.replace(p)
def worker(meta,design,dt):return evaluate("door_prop",design,meta["seed"],dt)
def main():
 p=argparse.ArgumentParser();p.add_argument("--tag",default="main_v1");p.add_argument("--workers",type=int,default=12);p.add_argument("--reference-design");p.add_argument("--reference-seeds",nargs="+",type=int,default=[0,1,2]+list(range(100,110)));a=p.parse_args()
 base=ROOT/"results"/a.tag;out=base/"release_collision_audit";out.mkdir(exist_ok=True)
 jobs=[]
 if a.reference_design:
  design=json.loads(pathlib.Path(a.reference_design).read_text())
  for seed in a.reference_seeds:
   for dt in [.002,.001]:
    meta={"reference":str(a.reference_design),"seed":seed,"timestep":dt};jobs.append((out/("reference_corrected_"+str(seed)+"_"+str(dt)+".json"),meta,design,dt))
 else:
  for path in base.glob("heldout/*/door_prop/run_*.json"):
   h=json.loads(path.read_text());sel=h["selection"];m,run=sel["model"],sel["run"];des=sel["proposal"]
   no=copy.deepcopy(des);no["tool"]=[]
   rod=copy.deepcopy(des);rod["tool"]=[{"type":"box","pos":[0,0,-.10],"size":[.008,.008,.10]}]
   fp=base/"search"/m/"door_prop"/f"run_{run}"/"candidate_0.json";first=json.loads(fp.read_text()).get("proposal",{"tool":[],"actions":[]})
   controls={"invented_tool":des,"first_candidate":first,"tool_removed":no,"generic_rod":rod}
   for row in h["rows"]:
    for dt in [.002,.001]:
     key=f"{m}__{run}__{row['condition']}__{row['seed']}__{dt}";dest=out/(key+".json")
     if dest.exists():continue
     meta={"model":m,"run":run,"condition":row["condition"],"seed":row["seed"],"main_success":bool(row.get("success")),"timestep":dt}
     if not meta["main_success"]:
      dump(dest,{**meta,"rerun":False,"corrected_success":False,"strict_corrected_success":False});continue
     jobs.append((dest,meta,controls[row["condition"]],dt))
 import multiprocessing as mp
 with cf.ProcessPoolExecutor(max_workers=a.workers,mp_context=mp.get_context("spawn")) as ex:
  futs={ex.submit(worker,meta,design,dt):(dest,meta) for dest,meta,design,dt in jobs}
  for f in cf.as_completed(futs):
   dest,meta=futs[f]
   try:
    r=f.result();dump(dest,{**meta,"rerun":True,"corrected_success":bool(r.get("success")),"strict_corrected_success":r["strict_corrected_success"],"result":r})
   except Exception as e:dump(dest,{**meta,"rerun":True,"corrected_success":False,"strict_corrected_success":False,"error":str(e)})
 rows=[json.loads(p.read_text()) for p in out.glob("*.json") if p.name!="summary.json" and not p.name.startswith("reference_")]
 summary={"diagnostic":"Posthoc release-contact correction; main frozen records unchanged","rows":len(rows),"models":{}}
 for m in ["astra","sol","opus"]:
  summary["models"][m]={}
  for cond in ["invented_tool","first_candidate","tool_removed","generic_rod"]:
   summary["models"][m][cond]={}
   for dt in [.002,.001]:
    rr=[r for r in rows if r.get("model")==m and r.get("condition")==cond and r.get("timestep")==dt]
    summary["models"][m][cond][str(dt)]={"main_successes":sum(r.get("main_success",False) for r in rr),"corrected_successes":sum(r.get("corrected_success",False) for r in rr),"strict_corrected_successes":sum(r.get("strict_corrected_success",False) for r in rr),"n":len(rr)}
 dump(out/"summary.json",summary);print(json.dumps(summary,indent=2))
if __name__=="__main__":main()

