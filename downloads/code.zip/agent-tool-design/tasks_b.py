"""Contact-only tool-use mechanisms; success comes from simulated state."""
import math
import random
import xml.etree.ElementTree as ET

TASKS = ("recessed_knob", "two_buttons", "door_prop")
def _s(v): return " ".join(str(float(x)) for x in v)
def _geom(parent, name, kind, pos, size, rgba=(.45,.48,.52,1), **kw):
    a=dict(name=name,type=kind,pos=_s(pos),size=_s(size),rgba=_s(rgba),friction="1 .01 .001")
    a.update({k:str(v) for k,v in kw.items()})
    return ET.SubElement(parent,"geom",a)
def _layout(task, seed):
    r=random.Random(8791+int(seed)*139)
    dx=r.uniform(-.006,.006) if seed else 0.; dy=r.uniform(-.006,.006) if seed else 0.
    if task=="recessed_knob": return dict(x=.56+dx,y=-.16+dy,knob_z=.092,knob_half=.015,opening_half=.037,wall_top=.185)
    if task=="two_buttons": return dict(x=.56+dx,y=.15+dy,spacing=.14+(r.uniform(-.004,.004) if seed else 0),button_z=.082,guard_top=.145)
    if task=="door_prop": return dict(x=.56+dx,y=dy,door_width=.28,door_height=.28,door_bottom=.04,door_top=.32,hinge_height=.18,hinge_y=-.14+dy,block_x=.79+dx,chamber_depth=.32,chamber_half_width=.30,block_y=.07+dy,block_z=.141)
    raise ValueError(task)
def build(task, worldbody, seed=0):
    p=_layout(task,seed); state=dict(task=task,seed=seed,layout=p)
    if task=="recessed_knob":
        x,y=p['x'],p['y']; h=p['opening_half']; top=p['wall_top']; bottom=.04
        for n,xx,yy,sx,sy in [('left',x-h-.012,y,.012,h+.024),('right',x+h+.012,y,.012,h+.024),('front',x,y-h-.012,h,.012),('back',x,y+h+.012,h,.012)]:
            _geom(worldbody,'knob_guard_'+n,'box',[xx,yy,(top+bottom)/2],[sx,sy,(top-bottom)/2],(.25,.30,.37,1))
        body=ET.SubElement(worldbody,'body',name='square_knob',pos=_s([x,y,p['knob_z']]))
        ET.SubElement(body,'joint',name='knob_hinge',type='hinge',axis='0 0 1',limited='true',range='0 1.70',damping='.012',frictionloss='.006')
        _geom(body,'knob_head','box',[0,0,0],[p['knob_half'],p['knob_half'],.012],(.95,.56,.12,1),mass='.04')
        _geom(body,'knob_shaft','cylinder',[0,0,-.025],[.006,.018],(.6,.6,.6,1),mass='.015')
        state.update(joint='knob_hinge',target_angle=1.15)
    elif task=="two_buttons":
        x,y=p['x'],p['y']; half=p['spacing']/2
        for i,yy in enumerate([y-half,y+half]):
            h=.022; top=p['guard_top']; bottom=.04
            for n,xx,yyy,sx,sy in [('l',x-h-.008,yy,.008,h+.016),('r',x+h+.008,yy,.008,h+.016),('f',x,yy-h-.008,h,.008),('b',x,yy+h+.008,h,.008)]:
                _geom(worldbody,f'button_guard_{i}_{n}','box',[xx,yyy,(top+bottom)/2],[sx,sy,(top-bottom)/2],(.25,.30,.37,1))
            body=ET.SubElement(worldbody,'body',name=f'button_{i}',pos=_s([x,yy,p['button_z']]))
            ET.SubElement(body,'joint',name=f'button_slide_{i}',type='slide',axis='0 0 1',limited='true',range='-.020 0',stiffness='150',springref='0',damping='.35')
            _geom(body,f'button_cap_{i}','cylinder',[0,0,0],[.014,.007],(.82,.16,.13,1),mass='.035')
        state.update(joints=['button_slide_0','button_slide_1'],pressed_threshold=-.010,simultaneous_seconds=0.,last_time=0.)
    elif task=="door_prop": return _build_door(worldbody,state)
    else: raise ValueError(task)
    return state

def measure(task, model, data, state):
    import mujoco
    if task=="recessed_knob":
        j=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,state['joint']); angle=float(data.qpos[model.jnt_qposadr[j]])
        return dict(success=angle>=state['target_angle'],score=min(1.,max(0.,angle/state['target_angle'])),angle_rad=angle,target_rad=state['target_angle'])
    if task=="two_buttons":
        q=[]
        for name in state['joints']:
            j=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,name); q.append(float(data.qpos[model.jnt_qposadr[j]]))
        pressed=all(v<state['pressed_threshold'] for v in q)
        dt=max(0.,float(data.time)-state.get('last_time',float(data.time)))
        if pressed: state['simultaneous_seconds']=state.get('simultaneous_seconds',0.)+dt
        else: state['simultaneous_seconds']=0.
        state['last_time']=float(data.time)
        return dict(success=pressed and state.get('simultaneous_seconds',0.)>=.15,score=min(1.,max(0.,min(-v for v in q)/.010)),button_displacements=q,simultaneous_seconds=state.get('simultaneous_seconds',0.),both_pressed_now=pressed)
    if task=="door_prop": return _measure_door(model,data,state)
    raise ValueError(task)
def spec(task,seed=0):
    p=_layout(task,seed)
    common=dict(task=task,coordinate_system='world metres; table top z=0.04; tool local axes coincide with world at identity quaternion',layout=p,rules=['Rigid tool starts attached to Panda tool mount.','Only contacts move task objects.','Task fixtures must not be altered.'])
    if task=='recessed_knob':
        common.update(description='Reach into a deep narrow square cavity and rotate its recessed square knob positive about world z by at least 1.15 radians. The hand cannot enter the 74 mm cavity.',geometry=dict(knob_center=[p['x'],p['y'],p['knob_z']],knob_half_extents=[.015,.015,.012],cavity_half_width=.037,cavity_wall_top=.185),success='Knob hinge angle >= 1.15 rad through physical tool contact.')
    elif task=='two_buttons':
        common.update(description='Press two spring-return buttons simultaneously for at least 0.15 simulated seconds. Each button is at the bottom of a guarded well. Their centres are nominally 140 mm apart.',geometry=dict(button_centers=[[p['x'],p['y']-p['spacing']/2,p['button_z']],[p['x'],p['y']+p['spacing']/2,p['button_z']]],button_radius=.014,well_half_width=.022,guard_top=.145,travel=.020),success='Both independent button joints displaced downward >= 10 mm continuously for >= .15 s at completion; spring stiffness150 N/m, damping .35 N s/m, buttonmass .035 kg.')
    elif task=='door_prop': common.update(description='Open an inward-swinging vertical spring-return door, leave a released physical prop holding it open, and use the free Panda gripper to retrieve the block through the doorway. The compartment has an open top; the block must cross the entrance below z=0.28 while the door is physically propped.',geometry=dict(door=dict(hinge_pos=[p['x'],p['y']-.14,.18],hinge_axis=[0,0,-1],closed_panel_center=[p['x'],p['y'],.18],panel_half_extents=[.006,.14,.14],angle_range=[0,1.5],spring_stiffness=.03,spring_damping=.015,doorway_y_bounds=[p['y']-.16,p['y']+.16],doorway_z_bounds=[.04,.32]),compartment=dict(open_top=True,inside_x_bounds=[p['x']+.01,p['x']+.32],inside_y_bounds=[p['y']-.30,p['y']+.30],wall_top=.36),block=dict(center=[p['block_x'],p['block_y'],p['block_z']],half_extents=[.018,.018,.021],mass=.045),pedestal=dict(center=[p['block_x'],p['block_y'],.08],half_extents=[.015,.012,.04])),success='Tool released before retrieval; gripper contacts block; block crosses entrance below z=door_top-.04 while released prop contacts door and door angle>.65; block ends x<entrance-.055 and door stays propped >=.3s after retrieval.')
    return common
def reference(task,seed=0):
    p=_layout(task,seed); x,y=p['x'],p['y']
    if task=='recessed_knob':
        geoms=[dict(type='box',pos=[0,0,-.055],size=[.012,.012,.055])]
        z=-.136; inner=.0165; outer=.023
        for a in [-1,1]:
            geoms.append(dict(type='box',pos=[a*(inner+outer)/2,0,z],size=[(outer-inner)/2,outer,.016]))
            geoms.append(dict(type='box',pos=[0,a*(inner+outer)/2,z],size=[inner,(outer-inner)/2,.016]))
        geoms.append(dict(type='box',pos=[0,0,-.114],size=[outer,outer,.006]))
        actions=[dict(pos=[x,y,.34],duration=1.2),dict(pos=[x,y,.228],duration=2.),dict(pos=[x,y,.228],quat=[math.cos(.75),0,0,math.sin(.75)],duration=3.),dict(pos=[x,y,.30],quat=[math.cos(.75),0,0,math.sin(.75)],duration=1.)]
        return dict(tool=dict(geoms=geoms),actions=actions,description='Deep four-wall square socket on a narrow shaft.')
    if task=='two_buttons':
        d=p['spacing']/2; geoms=[dict(type='box',pos=[0,0,-.0225],size=[.011,.011,.0225]),dict(type='box',pos=[0,0,-.045],size=[.011,d+.011,.011])]
        for yy in [-d,d]: geoms.append(dict(type='cylinder',pos=[0,yy,-.104],size=[.008,.059]))
        return dict(tool=dict(geoms=geoms),actions=[dict(pos=[x,y,.34],duration=1.2),dict(pos=[x,y,.239],duration=2.),dict(pos=[x,y,.239],duration=1.)],description='Rigid bridge with two slim parallel plungers matched to the guarded button spacing.')
    if task=='door_prop': return _reference_door(p)
    raise ValueError(task)

# A vertical-axis spring-return door with an open-top retrieval compartment.
def _build_door(worldbody,state):
    p=state['layout'];x,y=p['x'],p['y']
    for name,xx,yy,sx,sy in [('left',x+.155,y-.309,.165,.009),('right',x+.155,y+.309,.165,.009),('back',x+.329,y,.009,.318)]:
        _geom(worldbody,'chamber_'+name,'box',[xx,yy,.20],[sx,sy,.16],(.28,.34,.40,1))
    # Fixed front jambs close the broad chamber except for the 280 mm doorway.
    for side in [-1,1]:
        _geom(worldbody,'door_jamb_'+str(side),'box',[x,y+side*.234,.18],[.010,.074,.14],(.28,.34,.40,1))
    door=ET.SubElement(worldbody,'body',name='spring_door',pos=_s([x,y-.14,.18]))
    ET.SubElement(door,'joint',name='door_hinge',type='hinge',axis='0 0 -1',limited='true',range='0 1.50',stiffness='.03',springref='0',damping='.015',frictionloss='.001')
    _geom(door,'door_panel','box',[0,.14,0],[.006,.14,.14],(.20,.55,.72,.85),mass='.08')
    _geom(worldbody,'block_pedestal','box',[p['block_x'],p['block_y'],.08],[.015,.012,.04],(.4,.4,.43,1))
    b=ET.SubElement(worldbody,'body',name='door_block',pos=_s([p['block_x'],p['block_y'],.141]))
    ET.SubElement(b,'freejoint',name='door_block_free')
    _geom(b,'door_block_geom','box',[0,0,0],[.018,.018,.021],(.91,.23,.17,1),mass='.045')
    state.update(door_joint='door_hinge',block='door_block',held_open_seconds=0.,last_time=0.,release_before_retrieval=False,door_tool_contact=False,max_open_angle=0.)
    return state

def _measure_door(model,data,state):
    import mujoco
    j=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_JOINT,'door_hinge')
    angle=float(data.qpos[model.jnt_qposadr[j]])
    b=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_BODY,'door_block'); pos=data.xpos[b].copy()
    door_geom=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,'door_panel')
    tool_body=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_BODY,'tool')
    tool_contact=False;gripper_contact=False
    finger_ids=[mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_BODY,n) for n in ['hand','left_finger','right_finger']]
    block_geom=mujoco.mj_name2id(model,mujoco.mjtObj.mjOBJ_GEOM,'door_block_geom')
    for c in data.contact:
        if c.geom1==door_geom and model.geom_bodyid[c.geom2]==tool_body: tool_contact=True
        if c.geom2==door_geom and model.geom_bodyid[c.geom1]==tool_body: tool_contact=True
        if c.geom1==block_geom and model.geom_bodyid[c.geom2] in finger_ids: gripper_contact=True
        if c.geom2==block_geom and model.geom_bodyid[c.geom1] in finger_ids: gripper_contact=True
    released=bool(state.get('tool_released',False))
    if released and gripper_contact: state['gripper_block_contact']=True
    entrance=state['layout']['x']
    previous_x=state.get('previous_block_x',float(pos[0]))
    if previous_x>=entrance and pos[0]<entrance and pos[2]<state['layout']['door_top']-.04 and released and angle>.65 and tool_contact and state.get('gripper_block_contact',False):
        state['crossed_open_door']=True
    state['previous_block_x']=float(pos[0])
    retrieved=bool(pos[0]<entrance-.055 and pos[2]>.035)
    dt=max(0.,float(data.time)-state.get('last_time',float(data.time)))
    state['last_time']=float(data.time); state['max_open_angle']=max(state['max_open_angle'],angle)
    if released and not retrieved: state['release_before_retrieval']=True
    if released and tool_contact: state['door_tool_contact']=True
    if released and angle>.65 and retrieved and tool_contact:
        state['held_open_seconds']+=dt
    else: state['held_open_seconds']=0.
    success=bool(state.get('crossed_open_door',False) and state.get('gripper_block_contact',False) and released and retrieved and angle>.65 and state['release_before_retrieval'] and state['door_tool_contact'] and state['held_open_seconds']>=.3)
    score=.25*min(1.,max(0.,state['max_open_angle']/.65))+.25*float(released and state['door_tool_contact'])+.25*float(state.get('gripper_block_contact',False))+.25*float(success)
    return dict(success=success,score=score,gripper_block_contact=state.get('gripper_block_contact',False),crossed_open_door=state.get('crossed_open_door',False),door_angle_rad=angle,block_pos=pos.tolist(),released=released,retrieved=retrieved,tool_contact_now=tool_contact,door_tool_contact=state['door_tool_contact'],held_open_seconds=state['held_open_seconds'],release_before_retrieval=state['release_before_retrieval'],max_open_angle_rad=state['max_open_angle'])

def _reference_door(p):
    x,y=p['x'],p['y']
    geoms=[dict(type='box',pos=[0,0,-.03],size=[.009,.009,.03]),dict(type='box',pos=[0,-.04,-.06],size=[.009,.05,.009]),dict(type='box',pos=[.075,-.08,-.06],size=[.085,.009,.009]),dict(type='box',pos=[.15,-.08,-.11],size=[.012,.018,.11]),dict(type='box',pos=[.08,-.05,-.21],size=[.10,.06,.010])]
    acts=[dict(pos=[x-.20,y,.38],duration=1.3),dict(pos=[x-.20,y,.28],duration=1.4),dict(pos=[x-.02,y,.28],duration=3.),dict(pos=[x-.02,y,.28],duration=1.5),dict(pos=[x-.02,y,.28],duration=.8,release_tool=True),dict(pos=[x-.18,y+.07,.36],duration=1.4),dict(pos=[p['block_x'],y+.07,.26],duration=2.),dict(pos=[p['block_x'],y+.07,.16],duration=1.6,gripper=1),dict(pos=[p['block_x'],y+.07,.16],duration=1.,gripper=0),dict(pos=[x-.10,y+.07,.16],duration=3.,gripper=0),dict(pos=[x-.10,y+.07,.20],duration=1.,gripper=0)]
    return dict(tool=dict(geoms=geoms),actions=acts,description='Broad-foot rigid post pushes a vertical spring door open, is released as a friction-supported prop, then free fingers retrieve the block.')
