"""Recompute every reported aggregate from immutable trial JSON."""
import json,pathlib,collections,math,statistics,argparse,hashlib
import numpy as np
ROOT=pathlib.Path(__file__).resolve().parent
TASKS=["tunnel_retrieval","plate_lifting","ball_transfer","recessed_knob","two_buttons","door_prop"]
NAMES={"tunnel_retrieval":"Tunnel","plate_lifting":"Plate","ball_transfer":"Balls","recessed_knob":"Knob","two_buttons":"Buttons","door_prop":"Door"}
LABELS={"astra":"Astra 6","sol":"Sol 6.1","opus":"Opus 5.5"}
def main():
 p=argparse.ArgumentParser();p.add_argument("--tag",default="main_v1");args=p.parse_args()
 folder=ROOT/"results"/args.tag
 held=[json.loads(p.read_text()) for p in folder.glob("heldout/*/*/run_*.json")]
 candidates=[json.loads(p.read_text()) for p in folder.glob("search/*/*/run_*/candidate_[0-9].json")]
 controls=json.loads((folder/"controls.json").read_text()) if (folder/"controls.json").exists() else {"rows":[]}
 expected={(m,t,r) for m in LABELS for t in TASKS for r in range(3)}
 found={(h["selection"]["model"],h["selection"]["task"],h["selection"]["run"]) for h in held}
 summary={"tag":args.tag,"searches_expected":len(expected),"searches_found":len(found),"missing_searches":sorted(expected-found),"candidate_records":len(candidates),"models":{},"controls":{},"trial_rows":sum(len(h["rows"]) for h in held)}
 for model in LABELS:
  modelheld=[h for h in held if h["selection"]["model"]==model]
  mc=[c for c in candidates if c["model"]==model];api=[c["api"] for c in mc if "api" in c]
  ms={"label":LABELS[model],"search_count":len(modelheld),"candidate_count":len(mc),"api_count":len(api),"api_seconds_sum":sum(a.get("seconds",0) for a in api),"returned_models":sorted({a.get("returned_model","unknown") for a in api}),"api_usage":{},"invalid_candidates":sum("proposal" in c and not c.get("parse_error") and any(r.get("violations") for r in c.get("train_results",[])) for c in mc),"parse_errors":sum(bool(c.get("parse_error")) for c in mc),"by_task":{},"conditions":{}}
  usage=collections.Counter()
  for a in api:
   for k,v in a.get("usage",{}).items():
    if isinstance(v,(int,float)):usage[k]+=v
  ms["api_usage"]=dict(usage)
  for task in TASKS:
   th=[h for h in modelheld if h["selection"]["task"]==task]
   ts={}
   for cond in ["invented_tool","first_candidate","tool_removed","generic_rod"]:
    perrun=[];rows=[]
    for h in th:
     rr=[r for r in h["rows"] if r["condition"]==cond]
     if rr:perrun.append(sum(bool(r.get("success")) for r in rr)/len(rr));rows+=rr
    ts[cond]={"successes":sum(bool(r.get("success")) for r in rows),"n":len(rows),"rate":sum(bool(r.get("success")) for r in rows)/max(1,len(rows)),"per_run_rates":perrun,"sd_across_searches":statistics.stdev(perrun) if len(perrun)>1 else 0.}
   ms["by_task"][task]=ts
  for cond in ["invented_tool","first_candidate","tool_removed","generic_rod"]:
   rr=[r for h in modelheld for r in h["rows"] if r["condition"]==cond]
   ms["conditions"][cond]={"successes":sum(bool(r.get("success")) for r in rr),"n":len(rr),"rate":sum(bool(r.get("success")) for r in rr)/max(1,len(rr))}
  # Fixed-six-task, search-level bootstrap. Scene replays are not independent inventions.
  rng=np.random.default_rng(92031);boot=[]
  arrays=[ms["by_task"][t]["invented_tool"]["per_run_rates"] for t in TASKS]
  if all(arrays):
   for _ in range(10000):boot.append(float(np.mean([np.mean(rng.choice(a,len(a),replace=True)) for a in arrays])))
   ms["macro_bootstrap95_search_level_fixed_tasks"]=np.percentile(boot,[2.5,97.5]).tolist()
  ms["selected_tool_mass_kg"]={}
  masses=[r.get("physics",{}).get("tool_mass") for h in modelheld for r in h["rows"] if r["condition"]=="invented_tool"]
  masses=[x for x in masses if x is not None]
  if masses:ms["selected_tool_mass_kg"]={"min":min(masses),"median":statistics.median(masses),"max":max(masses)}
  summary["models"][model]=ms
 for task in TASKS:
  summary["controls"][task]={}
  for cond in ["reference","idle"]:
   rr=[r for r in controls["rows"] if r["task"]==task and r["condition"]==cond]
   summary["controls"][task][cond]={"successes":sum(bool(r.get("success")) for r in rr),"n":len(rr)}
 summary["controls"]["door_prop"]["reference"]["invalidated_by_posthoc_collision_audit"]=True
 out=ROOT/"analysis";out.mkdir(exist_ok=True)

 import csv
 flat=[]
 for h in held:
  sel=h["selection"]
  for r in h["rows"]:
   flat.append({"model":sel["model"],"task":sel["task"],"search_run":sel["run"],"selected_attempt":sel["selected_attempt"],"condition":r["condition"],"scene_seed":r["seed"],"success":r.get("success",False),"score":r.get("score",0),"violations":"; ".join(r.get("violations",[])),"tracking_mean_m":r.get("tracking_error",{}).get("mean"),"tracking_max_m":r.get("tracking_error",{}).get("max"),"max_penetration_m":r.get("physics",{}).get("max_all_contact_penetration"),"tool_mass_kg":r.get("physics",{}).get("tool_mass"),"max_contact_force_N":r.get("physics",{}).get("max_tool_contact_force"),"sim_seconds":r.get("sim_seconds"),"wall_seconds":r.get("walltime")})
 if flat:
  with (out/"trials.csv").open("w",newline="") as f:
   w=csv.DictWriter(f,fieldnames=list(flat[0]));w.writeheader();w.writerows(flat)
 candidateflat=[]
 for c in candidates:
  api=c.get("api",{});u=api.get("usage",{})
  candidateflat.append({"model":c["model"],"task":c["task"],"search_run":c["run"],"attempt":c["attempt"],"train_successes":sum(r.get("success",False) for r in c.get("train_results",[])),"valid_training_scenes":sum(not r.get("violations") for r in c.get("train_results",[])),"parse_error":c.get("parse_error",""),"response_id":api.get("id"),"requested_model":api.get("requested_model"),"returned_model":api.get("returned_model"),"status":api.get("status"),"input_tokens":u.get("input_tokens"),"output_tokens":u.get("output_tokens"),"api_seconds":api.get("seconds")})
 if candidateflat:
  with (out/"candidates.csv").open("w",newline="") as f:
   w=csv.DictWriter(f,fieldnames=list(candidateflat[0]));w.writeheader();w.writerows(candidateflat)

 (out/"summary.json").write_text(json.dumps(summary,indent=2))
 lines=["# Recomputed experiment summary","",f"Searches: {len(found)}/{len(expected)}; candidates: {len(candidates)}/216.","","| Model | "+" | ".join(NAMES[t] for t in TASKS)+" | Overall |","|---|"+"---|"*7]
 tex=[r"\begin{tabular}{lrrrrrrr}",r"\toprule",r"Model & Tunnel & Plate & Balls & Knob & Buttons & Door & Mean \\",r"\midrule"]
 for model,ms in summary["models"].items():
  cells=[]
  for task in TASKS:
   x=ms["by_task"][task]["invented_tool"];cells.append(f"{x['successes']}/{x['n']}")
  ov=ms["conditions"]["invented_tool"]
  lines.append("| "+ms["label"]+" | "+" | ".join(cells)+f" | {ov['rate']*100:.1f}% |")
  tex.append(ms["label"]+" & "+" & ".join(cells)+f" & {ov['rate']*100:.1f}"+r"\% \\")
 refcells=[f"{summary['controls'][t]['reference']['successes']}/{summary['controls'][t]['reference']['n']}" for t in TASKS]
 lines+=["| Original scripted reference* | "+" | ".join(refcells)+" | |","","*The original scripted door reference fails the posthoc restored-contact audit. Its raw count is preserved, but is not valid physical-success evidence. The corrected posthoc scripted reference is separate.","","Tool removal and generic rod reuse the selected action program; they are ablations, not independently optimized baselines.","","Replays share their generated design. Only the three design searches per task/model are independent synthesis repetitions."]
 tex+=[r"\midrule","Scripted reference & "+" & ".join(refcells)+r" & -- \\",r"\bottomrule",r"\end{tabular}"]
 (out/"summary.md").write_text("\n".join(lines)+"\n");(out/"results_table.tex").write_text("\n".join(tex)+"\n")
 import matplotlib
 matplotlib.use("Agg")
 import matplotlib.pyplot as plt
 plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,"axes.spines.right":False,"savefig.bbox":"tight"})
 fig,axs=plt.subplots(1,2,figsize=(7.0,2.25),gridspec_kw={"width_ratios":[1.5,1]})
 xx=np.arange(6);colors={"astra":"#3d679a","sol":"#419a85","opus":"#c47e3b"}
 for i,(model,ms) in enumerate(summary["models"].items()):
  vals=[ms["by_task"][t]["invented_tool"]["rate"]*100 for t in TASKS]
  err=[ms["by_task"][t]["invented_tool"]["sd_across_searches"]*100 for t in TASKS]
  axs[0].bar(xx+(i-1)*.23,vals,width=.22,label=ms["label"],color=colors[model])
  for j,task in enumerate(TASKS):
   pts=ms["by_task"][task]["invented_tool"]["per_run_rates"]
   if pts:axs[0].scatter(j+(i-1)*.23+np.linspace(-.04,.04,len(pts)),np.array(pts)*100,s=9,c="#172431",zorder=5,linewidths=.3,edgecolors="white")
 axs[0].set_xticks(xx,[NAMES[t] for t in TASKS]);axs[0].set_ylim(0,110);axs[0].set_ylabel("Held-out success (%)");axs[0].legend(frameon=False,ncol=3,fontsize=7,loc="upper center",bbox_to_anchor=(.5,1.2))
 for i,(model,ms) in enumerate(summary["models"].items()):
  vals=[ms["conditions"][c]["rate"]*100 for c in ["first_candidate","invented_tool","tool_removed","generic_rod"]]
  axs[1].plot(range(4),vals,"o-",label=ms["label"],color=colors[model],linewidth=1.4,markersize=4)
 axs[1].set_xticks(range(4),["First","Selected","Removed","Rod"],rotation=25);axs[1].set_ylim(0,105);axs[1].set_ylabel("Macro success (%)")
 fig.tight_layout(w_pad=1.3);fig.savefig(out/"results_plot.png",dpi=220);fig.savefig(out/"results_plot.pdf");plt.close(fig)
 print(json.dumps({"searches":len(found),"candidates":len(candidates),"missing":summary["missing_searches"],"models":{m:x["conditions"] for m,x in summary["models"].items()}},indent=2))
if __name__=="__main__":main()

