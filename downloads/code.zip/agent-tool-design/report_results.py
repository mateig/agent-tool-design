"""Recalculate the reported five-task rates from recorded trial outcomes."""
from pathlib import Path
from collections import defaultdict
import csv
rows=list(csv.DictReader((Path(__file__).parent/"analysis/five_task/validated_trials.csv").open()))
groups=defaultdict(list)
for row in rows:
    if row["condition"]=="invented_tool":
        groups[row["model"]].append(row["retained"]=="True")
for name in ["astra","sol","opus"]:
    outcomes=groups[name]
    print(f"{name}: {sum(outcomes)}/{len(outcomes)} = {100*sum(outcomes)/len(outcomes):.1f}%")
all_rows=[value for values in groups.values() for value in values]
print(f"overall: {sum(all_rows)}/{len(all_rows)} = {100*sum(all_rows)/len(all_rows):.1f}%")
